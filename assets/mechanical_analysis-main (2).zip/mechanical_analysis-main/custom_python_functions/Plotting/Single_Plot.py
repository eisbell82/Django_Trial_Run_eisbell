import pandas as pd 
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.lines as mlines
import numpy as np
import os
from IPython.display import display, HTML, clear_output
import ipywidgets as widgets
import Plotting.Polyfit_Processor as pp
import Plotting.Max_Processor as mp
import plotly.graph_objects as go
import re
import Utility.csv_file_browser as cb

def get_file_path_from_summary_row(summary_row):
    for key in ['Full Path', 'File Path', 'selected_file_path']:
        if key in summary_row and isinstance(summary_row[key], str) and os.path.exists(summary_row[key]):
            return summary_row[key]
    return None

def plot_from_csv_results(df_or_dict):
    """
    Accepts either a DataFrame or a dict with a 'selected_df' key.
    """
    # Determine input type
    if isinstance(df_or_dict, dict):
        df = df_or_dict.get("selected_df")
    else:
        df = df_or_dict

    if df is None or df.empty:
        print("❌ No data to plot.")
        return

    original_columns = df.columns.tolist()

    # Find corrected columns, even if they have units in the name
    stress_cols = [col for col in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", col)]
    strain_cols = [col for col in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", col)]
    
    if not stress_cols or not strain_cols:
        df = mp.correct_stress_and_strain(df)
        print("⚠️ No corrected stress/strain columns found for plotting. Corrected columns have been made.")
        return
    
    x_col, y_col = strain_cols[0], stress_cols[0]

    print(f"Found: Strain='{x_col}', Stress='{y_col}'")

    try:
        df[x_col] = pd.to_numeric(df[x_col], errors='coerce')
        df[y_col] = pd.to_numeric(df[y_col], errors='coerce')
        df_clean = df[[x_col, y_col]].dropna()
    except Exception as e:
        print(f"❌ Error converting columns to numeric: {e}")
        return

    if df_clean.empty:
        print("❌ All rows are NaN after conversion.")
        return

    plot_fivethirtyeight_style(df_clean[x_col], df_clean[y_col], x_label=x_col, y_label=y_col)

def plot_from_summary_row(input_obj, markers=None):
    """
    Plots stress-strain curves from a DataFrame, dict, or list of dicts.
    Adds markers for yield stress and inflection with correct styles and labels.
    'markers' can be:
      - None (default): plot all markers
      - string: e.g. "inflection" (only plot inflection markers)
      - list/tuple of strings: e.g. ("inflection", "max")
    Allowed: "max", "inflection"
    """

    # --- Normalize marker selection ---
    # [DISABLED] "curvature" removed as a strength definition — add it back to re-enable.
    allowed_types = {"max", "inflection"}  # , "curvature"
    if markers is None or markers is True:
        show_markers = allowed_types
    elif markers is False:
        show_markers = set()
    elif isinstance(markers, str):
        show_markers = {markers}
    else:
        show_markers = set(markers) & allowed_types

    marker_key_map = {
        "max": "yield_stress",
        "inflection": "inflection",
        # [DISABLED] "curvature": "strongest_curvature",  — removed as a strength definition
    }

    # Normalize input
    if isinstance(input_obj, pd.DataFrame):
        df = input_obj
        file_path = df.attrs.get('file_path', 'Unknown')
        curve_analysis = df.attrs.get('curve_analysis', {})
        results_list = [{"selected_df": df, "selected_file_path": file_path, "curve_analysis": curve_analysis}]
        is_single = True
    elif isinstance(input_obj, dict):
        results_list = [input_obj]
        is_single = True
    elif isinstance(input_obj, list):
        results_list = input_obj
        is_single = False
    else:
        print("❌ Invalid input: must be a DataFrame, dict, or list of dicts.")
        return

    data_series = []
    all_markers = []
    cmap = cm.get_cmap('tab10')

    for i, result in enumerate(results_list):
        # Get DataFrame and file_path
        df = result.get('selected_df') if isinstance(result, dict) else None
        if df is None and isinstance(result, pd.DataFrame):
            df = result
        file_path = result.get('selected_file_path', None) if isinstance(result, dict) else None
        if file_path is None and hasattr(df, 'attrs'):
            file_path = df.attrs.get('file_path', 'Unknown')

        if file_path and not isinstance(df, pd.DataFrame) and not os.path.exists(file_path):
            print(f"⚠️ Skipping: Invalid file path for item {i}")
            continue

        try:
            if df is None and file_path:
                df = pd.read_csv(file_path)
            if df is None or df.empty:
                print(f"⚠️ Skipping: No valid data in item {i}")
                continue

            # Robust header search for corrected columns
            stress_cols = [col for col in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", col)]
            strain_cols = [col for col in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", col)]

            if not stress_cols or not strain_cols:
                df = mp.correct_stress_and_strain(df, path=file_path if file_path else None)
                print(f"⚠️ No corrected columns found. Added corrections for {file_path}.")
                stress_cols = [col for col in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", col)]
                strain_cols = [col for col in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", col)]
                if not stress_cols or not strain_cols:
                    print(f"❌ Still missing corrected columns after correction for {file_path}. Skipping.")
                    continue

            x_col, y_col = strain_cols[0], stress_cols[0]
            df[x_col] = pd.to_numeric(df[x_col], errors='coerce')
            df[y_col] = pd.to_numeric(df[y_col], errors='coerce')
            df_clean = df[[x_col, y_col]].dropna()

            if df_clean.empty:
                print(f"⚠️ Skipping: No valid data after cleaning for {file_path}")
                continue

            label = os.path.basename(file_path) if file_path else f"Curve {i+1}"
            color = cmap(i % 10)

            data_series.append({
                'x': df_clean[x_col],
                'y': df_clean[y_col],
                'label': label
            })

            # --- Marker extraction with marker filtering ---
            curve_analysis = None
            if hasattr(df, 'attrs') and 'curve_analysis' in df.attrs:
                curve_analysis = df.attrs['curve_analysis']
            elif isinstance(result, dict):
                curve_analysis = result.get('curve_analysis', {})
            if not curve_analysis:
                curve_analysis = {}

            for mtype, mkey in marker_key_map.items():
                if mtype not in show_markers:
                    continue
                point = curve_analysis.get(mkey)
                if point and point.get('strain') is not None and point.get('stress') is not None:
                    all_markers.append({
                        'x': point['strain'],
                        'y': point['stress'],
                        'kind': mtype,  # e.g. "max", "inflection", "curvature"
                        'label': f"{label} - {mkey.replace('_', ' ').title()}",
                        'color': color
                    })

        except Exception as e:
            print(f"❌ Could not read/process item {i}: {e}")
            continue

    if not data_series:
        print("❌ No data to plot.")
        return

    title = data_series[0]['label'] if is_single else "Group Stress vs Strain"
    plot_fivethirtyeight_style(
        data_series=data_series,
        title=title,
        x_label=x_col if 'x_col' in locals() else 'Strain',
        y_label=y_col if 'y_col' in locals() else 'Stress',
        markers=all_markers if all_markers else None
    )

def _auto_axis_limits(x_arrays, y_arrays, markers, x_margin=2.0, y_margin=1.25):
    """
    Compute (xlim, ylim) = ((0, x_auto), (0, y_auto)) for strength plots.

    x_auto = max(marker strain values) * x_margin
             Falls back to data x_max when no markers are present.
    y_auto = max(stress within [0, x_auto] across all curves) * y_margin

    Parameters
    ----------
    x_arrays, y_arrays : lists of array-like, one entry per curve.
    markers : list of dicts with an 'x' key, or None/[].
    x_margin, y_margin : float multipliers applied to the derived limits.
    """
    marker_strains = [
        float(m['x']) for m in (markers or [])
        if m.get('x') is not None and np.isfinite(float(m['x']))
    ]
    if marker_strains:
        x_auto = max(marker_strains) * x_margin
    else:
        all_x = np.concatenate([np.asarray(xa, dtype=float).ravel()
                                 for xa in x_arrays]) if x_arrays else np.array([50.0])
        x_auto = float(np.nanmax(all_x)) if len(all_x) > 0 else 50.0

    max_y = 0.0
    for xa, ya in zip(x_arrays, y_arrays):
        xa = np.asarray(xa, dtype=float).ravel()
        ya = np.asarray(ya, dtype=float).ravel()
        mask = (xa >= 0) & (xa <= x_auto) & np.isfinite(ya)
        if np.any(mask):
            max_y = max(max_y, float(np.nanmax(ya[mask])))
    y_auto = max_y * y_margin if max_y > 0 else 1.0

    return (0.0, x_auto), (0.0, y_auto)


def plot_fivethirtyeight_style(x=None, y=None, data_series=None,
                               x_label='Strain', y_label='Stress',
                               title='Stress vs Strain', figsize=(12, 8), markers=None,
                               x_margin=2.0, y_margin=1.25):
    """
    Interactive stress-strain plot with range sliders for axis control.

    Auto-scale behaviour (when markers are provided):
      x_max = max(marker strain) * x_margin  — default x_margin=2.0
      y_max = max(stress within [0, x_max])  * y_margin — default y_margin=1.25
    Both axes start at 0. The sliders are initialised to these limits and
    can be adjusted interactively. Falls back to full data range when no
    markers are present.

    Parameters
    ----------
    x, y : array-like, optional
        Single curve data. Use data_series for multiple curves.
    data_series : list of dicts, optional
        Each dict must have 'x', 'y', and 'label' keys.
    markers : list of dicts, optional
        Each dict must have 'x', 'y', 'kind', and 'label' keys.
        Used to compute auto axis limits and drawn as scatter points.
    x_margin, y_margin : float
        Multipliers applied to marker-derived axis limits.
    """
    cmap = matplotlib.colormaps['tab10']
    legend_handles = []
    shown_marker_labels = set()

    curve_handles = []
    curve_labels = []

    all_x_vals = []
    all_y_vals = []

    # --- Collect all x/y values for slider limits ---
    if data_series is not None:
        for i, series in enumerate(data_series):
            all_x_vals.extend(series['x'])
            all_y_vals.extend(series['y'])
    elif x is not None and y is not None:
        all_x_vals.extend(x)
        all_y_vals.extend(y)

    # Default slider range
    x_min = float(np.nanmin(all_x_vals)) if all_x_vals else 0.0
    x_max = float(np.nanmax(all_x_vals)) if all_x_vals else 1.0
    y_min = float(np.nanmin(all_y_vals)) if all_y_vals else 0.0
    y_max = float(np.nanmax(all_y_vals)) if all_y_vals else 1.0

    # Central state for slider values
    state = {
        "x_range": [x_min, x_max],
        "y_range": [y_min, y_max]
    }

    output = widgets.Output()

    def draw_plot():
        nonlocal legend_handles, shown_marker_labels
        legend_handles = []
        shown_marker_labels = set()

        with output:
            clear_output(wait=True)
            fig, ax = plt.subplots(figsize=figsize)
            fig.patch.set_facecolor('white')
            ax.set_facecolor('white')

            if data_series is not None:
                for i, series in enumerate(data_series):
                    color = series.get('color', cmap(i % 10))
                    label = series.get('label', f'Curve {i+1}')
                    line, = ax.plot(series['x'], series['y'], linestyle='-', linewidth=5, label=label, color=color)
                    if label not in curve_labels:
                        curve_labels.append(label)
                        curve_handles.append(line)
            elif x is not None and y is not None:
                line, = ax.plot(x, y, linestyle='-', color='steelblue', linewidth=5, label='Curve')
                if 'Curve' not in curve_labels:
                    curve_labels.append('Curve')
                    curve_handles.append(line)

            if markers:
                marker_type_styles = {
                    'max':        ('X', "Yield Stress"),
                    'inflection': ('o', "Inflection"),
                    # [DISABLED] 'curvature': ('D', "Strongest Curvature"),  — removed as a strength definition
                }
                for m in markers:
                    marker_kind = m.get('kind')
                    marker_style, legend_label = marker_type_styles.get(
                        marker_kind, ('x', 'Marker')
                    )
                    # Plot each marker dot in the colour of its source curve
                    plot_color = m.get('color', 'black')
                    ax.plot(m['x'], m['y'], marker=marker_style, markersize=16, mew=2,
                            linestyle='None', color=plot_color)

                    # One black legend entry per marker type — keeps the legend compact
                    if legend_label not in shown_marker_labels:
                        shown_marker_labels.add(legend_label)
                        legend_handles.append(
                            mlines.Line2D([], [], color='black', marker=marker_style,
                                          linestyle='None', markersize=14, label=legend_label)
                        )

            ax.set_xlim(state["x_range"])
            ax.set_ylim(state["y_range"])
            ax.grid(True, color='gray', linewidth=0.6, alpha=0.6)
            ax.axhline(0, color='gray', linewidth=0.8, linestyle='--')
            ax.axvline(0, color='gray', linewidth=0.8, linestyle='--')

            for spine in ['top', 'right']:
                ax.spines[spine].set_visible(False)
            for spine in ['left', 'bottom']:
                ax.spines[spine].set_color('black')
                ax.spines[spine].set_linewidth(1.0)

            ax.set_xlabel(x_label, fontsize=20)
            ax.set_ylabel(y_label, fontsize=20)
            ax.tick_params(axis='both', which='major', labelsize=16, color='black')
            ax.set_title(title, fontsize=20)

            if curve_handles or legend_handles:
                ax.legend(handles=curve_handles + legend_handles,
                          labels=curve_labels + [h.get_label() for h in legend_handles],
                          fontsize=14, loc='upper left')

            plt.tight_layout()
            plt.show()

    def update_and_draw(*_):
        draw_plot()

    # Compute smart initial axis limits from markers when available
    _x_arrs = [s['x'] for s in (data_series or [])] + ([x] if x is not None else [])
    _y_arrs = [s['y'] for s in (data_series or [])] + ([y] if y is not None else [])
    _xlim_auto, _ylim_auto = _auto_axis_limits(_x_arrs, _y_arrs, markers,
                                               x_margin=x_margin, y_margin=y_margin)
    x_init_max = min(_xlim_auto[1], x_max) if x_max > 0 else _xlim_auto[1]
    y_init_max = min(_ylim_auto[1], y_max) if y_max > 0 else _ylim_auto[1]
    state["x_range"] = [0.0, x_init_max]
    state["y_range"] = [0.0, y_init_max]

    # Use cb.add_slider_widget for X and Y range sliders
    x_slider = cb.add_slider_widget(
        state, "x_range",
        description="X Range (Strain):",
        min_val=0, max_val=x_max, step=(x_max - 0) / 100 if x_max > 0 else 0.01,
        initial=[0, x_init_max],
        callback=update_and_draw
    )
    y_slider = cb.add_slider_widget(
        state, "y_range",
        description="Y Range (Stress):",
        min_val=y_min, max_val=y_max, step=(y_max - y_min) / 100 if y_max > y_min else 0.01,
        initial=[0, y_init_max],
        callback=update_and_draw
    )

    draw_plot()
    display(widgets.VBox([output, x_slider, y_slider]))

def export_all_strength_svg(
    target_folder,
    output_folder=None,
    markers=None,
    xlim=None,
    ylim=None,
    x_margin=2.0,
    y_margin=1.25
):
    """
    Processes every CSV in target_folder and saves one SVG per specimen to
    output_folder. Files are named <specimen>_strength.svg.

    Auto-scale behaviour (xlim/ylim=None, the default):
      x_max = max(marker strain) * x_margin  (default x_margin=2.0)
      y_max = max(stress within [0, x_max])  * y_margin (default y_margin=1.25)
    Pass explicit xlim/ylim tuples to override per-plot auto-scaling.

    Parameters
    ----------
    target_folder : str
        Folder to search recursively for CSV files.
    output_folder : str, optional
        Destination folder for the SVGs. Defaults to ./output/ relative to cwd.
    markers : None, bool, str, or list of str
        Marker types to show. None/True = all ("max", "inflection"),
        False = none, string or list = named subset.
    xlim : tuple of (float, float), optional
        Strain axis limits shared by every exported SVG, e.g. (0, 25).
        When None (default), each plot auto-scales from its markers.
    ylim : tuple of (float, float), optional
        Stress axis limits shared by every exported SVG, e.g. (0, 0.5).
        When None (default), each plot auto-scales from its data.
    x_margin, y_margin : float
        Multipliers for the auto-scale limits (ignored when xlim/ylim set).
    """
    if output_folder is None:
        output_folder = os.path.join(os.getcwd(), "output")
    os.makedirs(output_folder, exist_ok=True)

    # [DISABLED] "curvature" removed as a strength definition — add it back to re-enable.
    allowed_types = {"max", "inflection"}  # , "curvature"
    if markers is None or markers is True:
        show_markers = allowed_types
    elif markers is False:
        show_markers = set()
    elif isinstance(markers, str):
        show_markers = {markers}
    else:
        show_markers = set(markers) & allowed_types

    marker_key_map = {
        "max": "yield_stress",
        "inflection": "inflection",
        # [DISABLED] "curvature": "strongest_curvature",  — removed as a strength definition
    }
    marker_type_styles = {
        'max':        ('X', "Yield Stress",  '#e63946'),  # red
        'inflection': ('o', "Inflection",    '#f4a261'),  # orange
        # [DISABLED] 'curvature': ('D', "Strongest Curvature", '#8338ec'),  — removed as a strength definition
    }

    df_index = cb.build_df_index(target_folder)
    if df_index is None or df_index.empty:
        print("❌ No CSVs found in target folder.")
        return []

    total = len(df_index)
    _prog = widgets.IntProgress(value=0, min=0, max=total, description='Exporting:',
                                bar_style='info', layout=widgets.Layout(width='80%'))
    _prog_label = widgets.Label(value=f'0 / {total} files')
    display(widgets.HBox([_prog, _prog_label]))

    saved = []
    for i, (_, row) in enumerate(df_index.iterrows()):
        path = row["Full Path"]
        label = row.get("File Name", os.path.basename(path))
        stem = os.path.splitext(label)[0]
        _prog.value = i + 1
        _prog_label.value = f'{i + 1} / {total} — {label}'
        if not os.path.exists(path):
            print(f"⚠️ Skipping (not found): {path}")
            continue
        try:
            df = cb.load_and_process_csv(path)
            if df is None or df.empty:
                print(f"⚠️ Skipping (empty): {path}")
                continue

            df_fit = pp.find_and_fit(df, path)
            mp.print_max_summary_df(df_fit)

            stress_cols = [c for c in df_fit.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", c)]
            strain_cols = [c for c in df_fit.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", c)]
            if not stress_cols or not strain_cols:
                print(f"⚠️ Skipping (no corrected columns): {label}")
                continue

            x_col, y_col = strain_cols[0], stress_cols[0]
            df_fit[x_col] = pd.to_numeric(df_fit[x_col], errors='coerce')
            df_fit[y_col] = pd.to_numeric(df_fit[y_col], errors='coerce')
            df_clean = df_fit[[x_col, y_col]].dropna()
            if df_clean.empty:
                continue

            # Extract stress units from column name, e.g. "Stress Corrected (MPa)" → "MPa"
            _u = re.search(r'\(([^)]+)\)', y_col)
            stress_units = _u.group(1) if _u else ''

            # Collect markers for this specimen only
            spec_markers = []
            curve_analysis = df_fit.attrs.get('curve_analysis', {})
            for mtype, mkey in marker_key_map.items():
                if mtype not in show_markers:
                    continue
                point = curve_analysis.get(mkey)
                if point and point.get('strain') is not None and point.get('stress') is not None:
                    spec_markers.append({'x': point['strain'], 'y': point['stress'], 'kind': mtype})

            # --- Draw individual figure ---
            fig, ax = plt.subplots(figsize=(12, 8))
            fig.patch.set_facecolor('white')
            ax.set_facecolor('white')

            ax.plot(df_clean[x_col].values, df_clean[y_col].values,
                    linestyle='-', linewidth=2.5, color='#4c72b0', label=stem)

            legend_handles = [mlines.Line2D([], [], color='#4c72b0', linestyle='-',
                                            linewidth=2.5, label=stem)]
            for m in spec_markers:
                marker_style, legend_label, marker_color = marker_type_styles.get(
                    m.get('kind'), ('x', 'Marker', '#333333')
                )
                ax.plot(m['x'], m['y'], marker=marker_style, markersize=14, mew=2,
                        linestyle='None', color=marker_color)
                val_str = f"{m['y']:.3g}{(' ' + stress_units) if stress_units else ''}"
                legend_handles.append(
                    mlines.Line2D([], [], color=marker_color, marker=marker_style,
                                  linestyle='None', markersize=12,
                                  label=f"{legend_label} = {val_str}")
                )

            ax.grid(True, color='gray', linewidth=0.6, alpha=0.6)
            ax.axhline(0, color='gray', linewidth=0.8, linestyle='--')
            ax.axvline(0, color='gray', linewidth=0.8, linestyle='--')
            for spine in ['top', 'right']:
                ax.spines[spine].set_visible(False)
            for spine in ['left', 'bottom']:
                ax.spines[spine].set_color('black')
                ax.spines[spine].set_linewidth(1.0)

            ax.set_xlabel(x_col, fontsize=18)
            ax.set_ylabel(y_col, fontsize=18)
            ax.tick_params(axis='both', which='major', labelsize=14, color='black')
            ax.set_title(stem, fontsize=18)
            _xlim = xlim
            _ylim = ylim
            if _xlim is None or _ylim is None:
                _xlim_auto, _ylim_auto = _auto_axis_limits(
                    [df_clean[x_col].values], [df_clean[y_col].values],
                    spec_markers, x_margin=x_margin, y_margin=y_margin
                )
                if _xlim is None:
                    _xlim = _xlim_auto
                if _ylim is None:
                    _ylim = _ylim_auto
            ax.set_xlim(_xlim)
            ax.set_ylim(_ylim)
            ax.legend(handles=legend_handles, fontsize=11, loc='upper left')

            plt.tight_layout()
            svg_path = os.path.join(output_folder, f"{stem}_strength.svg")
            fig.savefig(svg_path, format='svg')
            plt.close(fig)
            saved.append(svg_path)

        except Exception as e:
            print(f"❌ Error processing {label}: {e}")
            continue

    print(f"✅ Saved {len(saved)} SVG(s) to: {output_folder}")
    return saved

def export_groups_strength_svg(
    target_folder,
    output_folder=None,
    markers=None,
    xlim=None,
    ylim=None,
    x_margin=2.0,
    y_margin=1.25
):
    """
    Processes every CSV in target_folder, groups specimens by subfolder
    (Specimen Group), and saves one SVG per group. Each SVG shows all
    specimens in that group overlaid on a single figure with yield stress
    and inflection markers. Files are named <group>_strength.svg.

    Auto-scale behaviour (xlim/ylim=None, the default):
      x_max = max(marker strain across group) * x_margin (default 2.0)
      y_max = max(stress within [0, x_max] across group) * y_margin (default 1.25)
    Pass explicit xlim/ylim tuples to use the same limits for every group.

    Parameters
    ----------
    target_folder : str
        Folder to search recursively for CSV files.
    output_folder : str, optional
        Destination folder for the SVGs. Defaults to ./output/ relative to cwd.
    markers : None, bool, str, or list of str
        Marker types to show. None/True = all ("max", "inflection"),
        False = none, string or list = named subset.
    """
    if output_folder is None:
        output_folder = os.path.join(os.getcwd(), "output")
    os.makedirs(output_folder, exist_ok=True)

    # [DISABLED] "curvature" removed as a strength definition — add it back to re-enable.
    allowed_types = {"max", "inflection"}  # , "curvature"
    if markers is None or markers is True:
        show_markers = allowed_types
    elif markers is False:
        show_markers = set()
    elif isinstance(markers, str):
        show_markers = {markers}
    else:
        show_markers = set(markers) & allowed_types

    marker_key_map = {
        "max": "yield_stress",
        "inflection": "inflection",
        # [DISABLED] "curvature": "strongest_curvature",  — removed as a strength definition
    }
    marker_type_styles = {
        'max':        ('X', "Yield Stress",  '#e63946'),  # red
        'inflection': ('o', "Inflection",    '#f4a261'),  # orange
        # [DISABLED] 'curvature': ('D', "Strongest Curvature", '#8338ec'),  — removed as a strength definition
    }

    df_index = cb.build_df_index(target_folder)
    if df_index is None or df_index.empty:
        print("❌ No CSVs found in target folder.")
        return []

    groups = sorted(df_index["Specimen Group"].dropna().unique())
    total = len(groups)
    _prog = widgets.IntProgress(value=0, min=0, max=total, description='Exporting:',
                                bar_style='info', layout=widgets.Layout(width='80%'))
    _prog_label = widgets.Label(value=f'0 / {total} groups')
    display(widgets.HBox([_prog, _prog_label]))

    cmap = matplotlib.colormaps['tab10']
    saved = []

    for g_i, group_name in enumerate(groups):
        _prog.value = g_i + 1
        _prog_label.value = f'{g_i + 1} / {total} — {group_name}'
        group_rows = df_index[df_index["Specimen Group"] == group_name]

        data_series = []
        all_markers = []
        x_col, y_col = 'Strain', 'Stress'

        for j, (_, row) in enumerate(group_rows.iterrows()):
            path = row["Full Path"]
            label = row.get("File Name", os.path.basename(path))
            stem = os.path.splitext(label)[0]
            if not os.path.exists(path):
                print(f"⚠️ Skipping (not found): {path}")
                continue
            try:
                df = cb.load_and_process_csv(path)
                if df is None or df.empty:
                    continue

                df_fit = pp.find_and_fit(df, path)
                mp.print_max_summary_df(df_fit)

                stress_cols = [c for c in df_fit.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", c)]
                strain_cols = [c for c in df_fit.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", c)]
                if not stress_cols or not strain_cols:
                    continue

                x_col, y_col = strain_cols[0], stress_cols[0]
                df_fit[x_col] = pd.to_numeric(df_fit[x_col], errors='coerce')
                df_fit[y_col] = pd.to_numeric(df_fit[y_col], errors='coerce')
                df_clean = df_fit[[x_col, y_col]].dropna()
                if df_clean.empty:
                    continue

                # Extract stress units from column name, e.g. "Stress Corrected (MPa)" → "MPa"
                _u = re.search(r'\(([^)]+)\)', y_col)
                stress_units = _u.group(1) if _u else ''

                color = cmap(j % 10)
                curve_analysis = df_fit.attrs.get('curve_analysis', {})

                # Add yield stress value to curve legend label
                ys_point = curve_analysis.get('yield_stress')
                if ys_point and ys_point.get('stress') is not None:
                    ys_val = f"{ys_point['stress']:.3g}{(' ' + stress_units) if stress_units else ''}"
                    series_label = f"{stem} — yield: {ys_val}"
                else:
                    series_label = stem

                data_series.append({
                    'x': df_clean[x_col].values, 'y': df_clean[y_col].values,
                    'label': series_label, 'color': color
                })

                for mtype, mkey in marker_key_map.items():
                    if mtype not in show_markers:
                        continue
                    point = curve_analysis.get(mkey)
                    if point and point.get('strain') is not None and point.get('stress') is not None:
                        all_markers.append({
                            'x': point['strain'], 'y': point['stress'],
                            'kind': mtype, 'color': color
                        })

            except Exception as e:
                print(f"❌ Error processing {label}: {e}")
                continue

        if not data_series:
            print(f"⚠️ No data for group: {group_name}")
            continue

        fig, ax = plt.subplots(figsize=(12, 8))
        fig.patch.set_facecolor('white')
        ax.set_facecolor('white')

        curve_handles = []
        for series in data_series:
            line, = ax.plot(series['x'], series['y'], linestyle='-', linewidth=2.5,
                            color=series['color'], label=series['label'])
            curve_handles.append(line)

        shown_marker_labels = set()
        legend_handles = list(curve_handles)
        for m in all_markers:
            marker_style, legend_label, marker_color = marker_type_styles.get(
                m.get('kind'), ('x', 'Marker', '#333333')
            )
            ax.plot(m['x'], m['y'], marker=marker_style, markersize=14, mew=2,
                    linestyle='None', color=marker_color)
            if legend_label not in shown_marker_labels:
                shown_marker_labels.add(legend_label)
                legend_handles.append(
                    mlines.Line2D([], [], color=marker_color, marker=marker_style,
                                  linestyle='None', markersize=12, label=legend_label)
                )

        ax.grid(True, color='gray', linewidth=0.6, alpha=0.6)
        ax.axhline(0, color='gray', linewidth=0.8, linestyle='--')
        ax.axvline(0, color='gray', linewidth=0.8, linestyle='--')
        for spine in ['top', 'right']:
            ax.spines[spine].set_visible(False)
        for spine in ['left', 'bottom']:
            ax.spines[spine].set_color('black')
            ax.spines[spine].set_linewidth(1.0)

        ax.set_xlabel(x_col, fontsize=18)
        ax.set_ylabel(y_col, fontsize=18)
        ax.tick_params(axis='both', which='major', labelsize=14, color='black')
        ax.set_title(group_name, fontsize=18)
        ax.legend(handles=legend_handles, fontsize=11, loc='upper left')

        _xlim_grp = xlim
        _ylim_grp = ylim
        if _xlim_grp is None or _ylim_grp is None:
            _xlim_auto, _ylim_auto = _auto_axis_limits(
                [np.asarray(s['x']) for s in data_series],
                [np.asarray(s['y']) for s in data_series],
                all_markers, x_margin=x_margin, y_margin=y_margin
            )
            if _xlim_grp is None:
                _xlim_grp = _xlim_auto
            if _ylim_grp is None:
                _ylim_grp = _ylim_auto
        ax.set_xlim(_xlim_grp)
        ax.set_ylim(_ylim_grp)

        plt.tight_layout()
        safe_name = group_name.replace('/', '_').replace('\\', '_')
        svg_path = os.path.join(output_folder, f"{safe_name}_strength.svg")
        fig.savefig(svg_path, format='svg')
        plt.close(fig)
        saved.append(svg_path)

    print(f"✅ Saved {len(saved)} group SVG(s) to: {output_folder}")
    return saved

def choose_and_plot_summary(summary_df):
    if 'Full Path' not in summary_df.columns:
        print("⚠️ 'Full Path' column missing from summary_df. Cannot proceed.")
        return

    options = [(row['File Name'], idx) for idx, row in summary_df.iterrows()]
    dropdown = widgets.Dropdown(options=options, description="Select File:", layout=widgets.Layout(width='100%'))

    def on_select(change):
        if change['type'] == 'change' and change['name'] == 'value':
            idx = change['new']
            summary_row = summary_df.iloc[idx]
            plot_from_summary_row(summary_row)

    dropdown.observe(on_select)
    display(dropdown)


def make_export_axis_widget(df):
    """
    Builds and displays an interactive widget for setting SVG export axis limits.

    Reads the data range from `df` to pre-fill the strain/stress fields.
    Returns a SimpleNamespace with `.xlim` and `.ylim` attributes that are
    updated live as the user adjusts the controls.  Pass them directly to
    `export_all_strength_svg(..., xlim=limits.xlim, ylim=limits.ylim)`.

    Two modes (toggled by the 'Auto (per-plot axes)' checkbox):
      - Auto   (default): xlim=None / ylim=None — each SVG auto-scales
        independently using marker-derived limits (x_margin=2.0, y_margin=1.25).
      - Manual : fixed (xlim, ylim) tuples shared by every exported SVG.
    """
    import types
    import re as _re

    state = types.SimpleNamespace(xlim=None, ylim=None)

    stress_cols = [c for c in df.columns if _re.match(r"^Stress Corrected(\s*\([^)]+\))?$", c)]
    strain_cols = [c for c in df.columns if _re.match(r"^Strain Corrected(\s*\([^)]+\))?$", c)]

    if stress_cols and strain_cols:
        _x = pd.to_numeric(df[strain_cols[0]], errors='coerce').dropna()
        _y = pd.to_numeric(df[stress_cols[0]], errors='coerce').dropna()
        xmin, xmax = float(_x.min()), float(_x.max())
        ymin, ymax = float(_y.min()), float(_y.max())
    else:
        xmin, xmax, ymin, ymax = 0.0, 50.0, 0.0, 1.0

    _style  = {'description_width': '110px'}
    _layout = widgets.Layout(width='230px')

    xmin_w = widgets.BoundedFloatText(value=max(0.0, xmin), min=-1e6, max=1e6, step=0.1,
                                      description='Strain min:', style=_style, layout=_layout)
    xmax_w = widgets.BoundedFloatText(value=xmax,             min=-1e6, max=1e6, step=0.1,
                                      description='Strain max:', style=_style, layout=_layout)
    ymin_w = widgets.BoundedFloatText(value=max(0.0, ymin),  min=-1e6, max=1e6, step=0.001,
                                      description='Stress min:', style=_style, layout=_layout)
    ymax_w = widgets.BoundedFloatText(value=ymax,             min=-1e6, max=1e6, step=0.001,
                                      description='Stress max:', style=_style, layout=_layout)
    auto_w = widgets.Checkbox(
        value=True,
        description='Auto (per-plot axes)',
        style={'description_width': 'initial'},
        layout=widgets.Layout(margin='4px 0 8px 0'),
    )

    state.xlim = None
    state.ylim = None
    for w in [xmin_w, xmax_w, ymin_w, ymax_w]:
        w.disabled = True

    def _fmt(v):
        return f"{v:.4g}"

    def _summary_text():
        if auto_w.value:
            return "<b>Export limits:</b> &nbsp; <i>Auto \u2014 each plot scales to its own data</i>"
        return (
            f"<b>Export limits:</b> &nbsp; "
            f"Strain [{_fmt(state.xlim[0])}, {_fmt(state.xlim[1])}] &nbsp;&nbsp; "
            f"Stress [{_fmt(state.ylim[0])}, {_fmt(state.ylim[1])}]"
        )

    summary = widgets.HTML(_summary_text())

    def _update(change):
        if auto_w.value:
            state.xlim = None
            state.ylim = None
            for w in [xmin_w, xmax_w, ymin_w, ymax_w]:
                w.disabled = True
        else:
            for w in [xmin_w, xmax_w, ymin_w, ymax_w]:
                w.disabled = False
            state.xlim = (xmin_w.value, xmax_w.value)
            state.ylim = (ymin_w.value, ymax_w.value)
        summary.value = _summary_text()

    for w in [xmin_w, xmax_w, ymin_w, ymax_w, auto_w]:
        w.observe(_update, names='value')

    info = widgets.HTML(
        f"<b>Current specimen data range</b><br>"
        f"Strain: {xmin:.4g}\u2013{xmax:.4g} &nbsp;&nbsp; "
        f"Stress: {ymin:.4g}\u2013{ymax:.4g}"
    )
    instructions = widgets.HTML(
        '<div style="margin-left:30px; padding:10px 14px; background:#f8f9fa;'
        '            border-left:3px solid #aaa; font-size:13px; line-height:1.7;'
        '            max-width:380px;">'
        '  <b>Instructions</b><br>'
        '  1. The fields are pre-filled with this specimen\'s data range.<br>'
        '  2. Adjust any value to crop all exported SVGs to the same window.<br>'
        '  3. Tick <i>Auto (per-plot axes)</i> to let each plot scale independently'
        '     to its own data \u2014 the manual fields are disabled in this mode.<br>'
        '  4. The <i>Export limits</i> line below updates as you type.<br>'
        '  5. Run the next cell to export \u2014 no need to re-run this one.'
        '</div>'
    )
    display(widgets.HBox([
        widgets.VBox([info, auto_w,
                      widgets.HBox([xmin_w, xmax_w]),
                      widgets.HBox([ymin_w, ymax_w]),
                      summary]),
        instructions,
    ]))
    return state
