import pandas as pd
import numpy as np
import os
from scipy.signal import savgol_filter
import plotly.express as px
import plotly.graph_objects as go
import traceback
import warnings
import re
from Plotting.Max_Processor import correct_stress_and_strain

SMOOTHING_WINDOW_LENGTH = 51
SMOOTHING_POLYORDER = 3

def r_squared(y_true, y_pred):
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    if not np.any(mask):
        return np.nan
    y_true = y_true[mask]
    y_pred = y_pred[mask]
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    return 1 - (ss_res / ss_tot)

def adjusted_r_squared(r2, n, k):
    return 1 - ((1 - r2) * (n - 1) / (n - k - 1))

def format_poly_equation(coeffs):
    terms = [f"{c:.4g}x^{i}" if i > 0 else f"{c:.4g}" for i, c in enumerate(reversed(coeffs))]
    return "f(x) = " + " + ".join(terms)

def safe_gradient(y, x):
    with np.errstate(divide='ignore', invalid='ignore'):
        return np.gradient(y, x)

def find_and_fit(df, path=None, overwrite=True):
    """
    Polynomial fit:
      - degrees 3–8 fit only region 0 <= strain <= 50 (% strain)
      - degree 9 fit over the entire data range
    All fits are evaluated over the entire x range for plotting and derivatives.
    - If overwrite=True, old fit/derivative columns (including duplicates) are dropped/replaced.
    - Will NOT overwrite or remove base/original data columns.
    - Saves updated CSV if path provided.
    """
    import warnings
    if df is None or df.empty:
        print("❌ Input DataFrame is empty.")
        return pd.DataFrame()

    # Find corrected columns, even with units
    stress_cols = [col for col in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", col)]
    strain_cols = [col for col in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", col)]
    if not stress_cols or not strain_cols:
        print("❌ Corrected columns missing.")
        return pd.DataFrame()

    x_col, y_col = strain_cols[0], stress_cols[0]
    x = df[x_col].values
    y = df[y_col].values

    fit_mask_0_50 = (x >= 0) & (x <= 50)
    fit_mask_all = np.isfinite(x) & np.isfinite(y)  # all finite values

    if np.sum(fit_mask_0_50) < 10:
        print("❌ Not enough data points between 0 and 50 percent strain to fit a degree-8 polynomial.")
        return pd.DataFrame()
    if np.sum(fit_mask_all) < 10:
        print("❌ Not enough data points to fit a degree-9 polynomial.")
        return pd.DataFrame()

    x_plot = x
    y_plot = y

    fits = {}
    stats = []
    # --- Degrees 3–8: fit only on 0–50% strain ---
    for deg in range(3, 9):
        try:
            coeffs = np.polyfit(x[fit_mask_0_50], y[fit_mask_0_50], deg=deg)
            y_fit_curve = np.polyval(coeffs, x_plot)  # always plot over all x
            r2 = r_squared(y[fit_mask_0_50], np.polyval(coeffs, x[fit_mask_0_50]))
            adj_r2 = adjusted_r_squared(r2, len(x[fit_mask_0_50]), len(coeffs))
            fits[f"Degree {deg}"] = (coeffs, y_fit_curve)
            stats.append({
                "degree": deg,
                "coeffs": coeffs,
                "adj_r2": adj_r2,
                "r2": r2,
                "curve": y_fit_curve
            })
        except Exception as e:
            print(f"⚠️ Degree {deg} fit failed: {e}")

    # --- Degree 9: fit on ALL available data ---
    try:
        coeffs_9 = np.polyfit(x[fit_mask_all], y[fit_mask_all], deg=9)
        y_fit_curve_9 = np.polyval(coeffs_9, x_plot)
        r2_9 = r_squared(y[fit_mask_all], np.polyval(coeffs_9, x[fit_mask_all]))
        adj_r2_9 = adjusted_r_squared(r2_9, len(x[fit_mask_all]), len(coeffs_9))
        fits["Degree 9"] = (coeffs_9, y_fit_curve_9)
        stats.append({
            "degree": 9,
            "coeffs": coeffs_9,
            "adj_r2": adj_r2_9,
            "r2": r2_9,
            "curve": y_fit_curve_9
        })
    except Exception as e:
        print(f"⚠️ Degree 9 fit failed: {e}")

    if not stats or "Degree 9" not in fits:
        print("❌ Degree 9 fit did not succeed (required for main curve).")
        return pd.DataFrame()

    # Always use degree 9 as "best" fit
    best_label = "Degree 9"
    best_curve = fits[best_label][1]
    best_coeffs = fits[best_label][0]

    df_result = df.copy()
    df_result.attrs["strain_col"] = x_col
    df_result.attrs["stress_col"] = y_col
    df_result.attrs["x_plot"] = x_plot
    df_result.attrs["y_plot"] = y_plot
    df_result.attrs["fit_curves"] = {k: v[1] for k, v in fits.items()}
    df_result.attrs["fit_coeffs"] = {k: v[0] for k, v in fits.items()}
    df_result.attrs["best_label"] = best_label
    df_result.attrs["best_coeffs"] = best_coeffs.tolist()
    df_result.attrs["equation_str"] = format_poly_equation(best_coeffs)
    df_result.attrs["adj_r_squared_dict"] = {f'Degree {d["degree"]}': d["adj_r2"] for d in stats}
    df_result.attrs["r_squared_dict"] = {f'Degree {d["degree"]}': d["r2"] for d in stats}
    df_result.attrs["adj_r_squared"] = df_result.attrs["adj_r_squared_dict"][best_label]
    df_result.attrs["r_squared"] = df_result.attrs["r_squared_dict"][best_label]
    df_result.attrs["y_smooth"] = savgol_filter(y, 51, 3) if len(y) > 51 else y
    df_result.attrs["fit_region_min"] = np.min(x[fit_mask_all])
    df_result.attrs["fit_region_max"] = np.max(x[fit_mask_all])

    # --- Overwrite/duplicate logic for fit/derivative columns ---
    fit_colnames = [
        "Polynomial Fit",
        "First Derivative (Fit)",
        "Second Derivative (Fit)",
    ]
    drop_cols = []
    for col in fit_colnames:
        if col in df_result.columns:
            if overwrite:
                drop_cols += [c for c in df_result.columns if c == col]
            else:
                idxs = [i for i, c in enumerate(df_result.columns) if c == col]
                if len(idxs) > 1:
                    print(f"⚠️ Multiple columns named '{col}' found. Removing duplicates (keeping the first).")
                    for j in idxs[1:]:
                        drop_cols.append(df_result.columns[j])
    if drop_cols:
        df_result = df_result.drop(columns=drop_cols)

    # If not overwriting and the fit columns exist, skip recompute
    if not overwrite and all(col in df_result.columns for col in fit_colnames):
        print("⚠️ Fit/derivative columns already present (and overwrite=False). Skipping recompute.")
    else:
        # Add the best fit column for compatibility (fit over full x)
        df_result["Polynomial Fit"] = best_curve
        # === ADD DERIVATIVE COLUMNS FOR POLYNOMIAL FIT ONLY ===
        try:
            df_result["First Derivative (Fit)"] = safe_gradient(best_curve, x)
        except Exception as e:
            print(f"⚠️ Could not compute first derivative: {e}")
            df_result["First Derivative (Fit)"] = np.nan
        try:
            df_result["Second Derivative (Fit)"] = safe_gradient(df_result["First Derivative (Fit)"].values, x)
        except Exception as e:
            print(f"⚠️ Could not compute second derivative: {e}")
            df_result["Second Derivative (Fit)"] = np.nan

    return df_result


def summarize_polynomial_fit(result_df):
    if not hasattr(result_df, "attrs"):
        print("❌ No metadata found in result DataFrame.")
        return

    meta = result_df.attrs
    eq = meta.get("equation_str", "N/A")
    deg = meta.get("best_degree", "?")
    r2 = meta.get("r_squared", np.nan)
    adj_r2 = meta.get("adj_r_squared", np.nan)

    print(f"Best Polynomial Degree: {deg}")
    print(f"R² (vs raw): {r2:.5f}")
    print(f"Adjusted R² (vs raw): {adj_r2:.5f}")
    print(f"Fitted Polynomial Equation: {eq}")

def plot_polynomial_fits(df_result, csv_results=None):

    if df_result is None or df_result.empty:
        print("df_result is empty — cannot generate plots.")
        return

    strain_col = df_result.attrs['strain_col']
    x_plot = df_result.attrs['x_plot']
    y_plot = df_result.attrs['y_plot']
    fit_curves = df_result.attrs['fit_curves']
    best_label = df_result.attrs['best_label']
    best_curve = fit_curves[best_label]
    adj_r2_dict = df_result.attrs['adj_r_squared_dict']
    r2_dict = df_result.attrs['r_squared_dict']

    # --- y axis scaling: y_max at 1.5x the max of the fitted curve from 0 to 50 (% strain) ---
    mask_0_50 = (x_plot >= 0) & (x_plot <= 50)
    y_max_fit = np.nanmax(best_curve[mask_0_50])
    y_max = 1.5 * y_max_fit

    plot_df = pd.DataFrame({strain_col: x_plot, "Original Stress": y_plot})
    for label, curve in fit_curves.items():
        plot_df[label] = curve

    # --- First plot: all fits 3-8 and original data ---
    fig = px.line(
        plot_df,
        x=strain_col,
        y=["Original Stress"] + list(fit_curves.keys()),
        labels={"value": "Stress", "variable": "Curve"},
        title="Polynomial Fits (Degree 3–8, always using 9 for final fit)<br>(Zoom or pan to see full data)"
    )
    fig.update_yaxes(range=[0, y_max])
    fig.update_xaxes(range=[0, 70])  # Show 0–70% by default, fully zoomable
    fig.show()

    print("Polynomial Fit R² and Adjusted R² Values (region 0–50% strain):")
    for label in fit_curves:
        print(f"{label}: R²={r2_dict[label]:.5f}, adj R²={adj_r2_dict[label]:.5f}")

    print(f"\nFinal fit: {best_label}")
    print(f"Equation: {df_result.attrs['equation_str']}")

    # --- Derivative plots for the best fit ---
    d1_fit = np.gradient(best_curve, x_plot)
    d2_fit = np.gradient(d1_fit, x_plot)
    zero_crossings = np.where(np.diff(np.signbit(d2_fit)))[0]
    zero_cross_x = x_plot[zero_crossings + 1]
    zero_cross_y = d2_fit[zero_crossings + 1]
    d3_fit = np.gradient(d2_fit, x_plot)
    minima_indices = [i for i in np.where((np.diff(np.sign(d3_fit)))[0] > 0)[0]]
    minima_x = x_plot[minima_indices]
    minima_y = d2_fit[minima_indices]

    # --- First derivative plot ---
    fig_d1 = px.line(
        pd.DataFrame({strain_col: x_plot, "First Derivative (Fit)": d1_fit}),
        x=strain_col,
        y="First Derivative (Fit)",
        title="First Derivative (Degree 9 Fit)"
    )
    fig_d1.update_xaxes(range=[0, 70])
    fig_d1.add_hline(y=0, line_dash="dash", line_color="gray")
    fig_d1.show()

    # --- Second derivative plot ---
    fig_d2 = go.Figure()
    fig_d2.add_trace(go.Scatter(x=x_plot, y=d2_fit,
                                mode='lines', name='Second Derivative (Degree 9 Fit)'))
    fig_d2.add_trace(go.Scatter(x=zero_cross_x, y=zero_cross_y,
                                mode='markers+text', textposition='top center',
                                marker=dict(symbol='x', size=10),
                                text=[f"Zero @ {v:.3g}" for v in zero_cross_x],
                                name='Zero Crossings'))
    fig_d2.add_trace(go.Scatter(x=minima_x, y=minima_y,
                                mode='markers+text', textposition='bottom center',
                                marker=dict(symbol='x', size=12),
                                text=[f"Min: {v:.3g}" for v in minima_y],
                                name='Minima of 2nd Derivative'))
    y_d2_max = max(np.nanmax(d2_fit), 0)
    y_d2_min = min(np.nanmin(d2_fit), 0)
    fig_d2.update_layout(
        title=f"Second Derivative (Degree 9 Fit)",
        xaxis_title=strain_col,
        yaxis_title="Second Derivative",
        xaxis_range=[0, 70],
        yaxis_range=[y_d2_min - 0.2*abs(y_d2_max-y_d2_min), y_d2_max + 0.2*abs(y_d2_max-y_d2_min)],
    )
    fig_d2.add_hline(y=0, line_dash="dash", line_color="red")
    fig_d2.show()
