import numpy as np
import pandas as pd
import warnings
import os
import Plotting.Single_Plot as sp
import Plotting.Multi_Plot as mult
import Utility.csv_file_browser as cb
import ipywidgets as widgets
from IPython.display import display, clear_output
import sys
import io
from collections import Counter
import base64
import re
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import json

def plot_moe_from_df(
    input_obj,
    fit_range=None,
    scan_min=None,
    scan_max=None,
    best_window=True,
    show_fit=True,
    xlim=(0, 15),
    ylim=None,
    y_margin=1.25
):
    """
    Plots stress-strain with modulus-of-elasticity (MOE) fit.
    - MOE fit is in dashed red, 3 significant digits.
    - Fit region uses best window if scan_min/scan_max and best_window provided.
    - X/Y axis limits adjustable.
    """
    if isinstance(input_obj, pd.DataFrame):
        results_list = [{'selected_df': input_obj, 'selected_file_path': input_obj.attrs.get('file_path', 'Unknown')}]
        is_single = True
    elif isinstance(input_obj, dict):
        results_list = [input_obj]
        is_single = True
    elif isinstance(input_obj, list):
        results_list = input_obj
        is_single = False
    else:
        print("❌ Invalid input: must be DataFrame, dict, or list of dicts.")
        return

    cmap = cm.get_cmap('tab10')
    plt.figure(figsize=(8, 6))
    _auto_max_y = 0.0

    for i, result in enumerate(results_list):
        df = result.get('selected_df') if isinstance(result, dict) else result
        file_path = result.get('selected_file_path', None) if isinstance(result, dict) else None
        if file_path is None and hasattr(df, 'attrs'):
            file_path = df.attrs.get('file_path', 'Unknown')

        # --- Find/correct columns ---
        stress_cols = [col for col in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", col)]
        strain_cols = [col for col in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", col)]
        if not stress_cols or not strain_cols:
            df = correct_stress_and_strain(df, path=file_path if file_path else None)
            stress_cols = [col for col in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", col)]
            strain_cols = [col for col in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", col)]
            if not stress_cols or not strain_cols:
                print(f"❌ Still missing corrected columns after correction for {file_path}. Skipping.")
                continue

        x_col, y_col = strain_cols[0], stress_cols[0]
        df[x_col] = pd.to_numeric(df[x_col], errors='coerce')
        df[y_col] = pd.to_numeric(df[y_col], errors='coerce')
        df_clean = df[[x_col, y_col]].dropna()
        if df_clean.empty:
            print(f"⚠️ Skipping: No valid data after cleaning for {file_path}")
            continue

        label = os.path.basename(file_path) if file_path else f"Curve {i+1}"
        color = cmap(i % 10)
        plt.plot(df_clean[x_col], df_clean[y_col], label=label, color=color, lw=1.5, alpha=0.7)
        _x = df_clean[x_col].values; _y = df_clean[y_col].values
        _mask = (_x >= xlim[0]) & (_x <= xlim[1]) & np.isfinite(_y)
        if np.any(_mask):
            _auto_max_y = max(_auto_max_y, float(np.nanmax(_y[_mask])))

        # --- Flexible fit window ---
        fit_kwargs = dict(
            fit_range=fit_range,
            scan_min=scan_min,
            scan_max=scan_max,
            best_window=best_window
        )
        result_fit = fit_modulus_from_df(df_clean, **fit_kwargs)

        if result_fit and show_fit:
            def sig(x, sig=3):
                if x == 0 or pd.isnull(x):
                    return "0"
                return f"{x:.{sig}g}"
            moe_str = sig(result_fit['modulus'], 3)
            r2_str = sig(result_fit['r2'], 3)
            fit_bounds = ""
            if 'fit_range' in result_fit:
                fit_bounds = f" [{result_fit['fit_range'][0]:.3f}–{result_fit['fit_range'][1]:.3f}]"
            plt.plot(
                result_fit['fit_x'], result_fit['fit_y'],
                '--', color='red', lw=2,
                label=f"MOE={moe_str}, R²={r2_str}{fit_bounds}"
            )

    plt.xlabel('Strain (corrected)')
    plt.ylabel('Stress (corrected)')
    plt.title("Stress-Strain with Elastic Modulus Fit")
    plt.xlim(xlim)
    _ylim = ylim if ylim is not None else (0.0, _auto_max_y * y_margin if _auto_max_y > 0 else 1.0)
    plt.ylim(_ylim)
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()

def correct_stress_and_strain(df, path=None, overwrite=True):
    """
    Adds or overwrites 'Stress Corrected (unit)' columns.
    If overwrite=True, deletes any previous corrected columns before writing new.
    """
    def _inner():
        def extract_unit(col):
            # Extract anything in parentheses at the end
            match = re.search(r'\(([^)]+)\)\s*$', col)
            if match:
                return match.group(1).strip()
            return None

        original_columns = df.columns.tolist()
        # Find existing corrected columns
        stress_corr_col = next((col for col in original_columns if col.lower().startswith("stress corrected")), None)
        strain_corr_col = next((col for col in original_columns if col.lower().startswith("strain corrected")), None)
        already_exists = [c for c in [stress_corr_col, strain_corr_col] if c]

        if already_exists and not overwrite:
            return df

        # Remove existing corrected columns if overwriting
        if overwrite:
            for col in [stress_corr_col, strain_corr_col]:
                if col and col in df.columns:
                    df.drop(columns=col, inplace=True)

        # Identify original columns and units
        original_columns = df.columns.tolist()
        stress_cols = [col for col in original_columns if "stress" in col.lower() and "corrected" not in col.lower()]
        strain_cols = [col for col in original_columns if "strain" in col.lower() and "corrected" not in col.lower()]

        if len(stress_cols) == 1 and len(strain_cols) == 1:
            stress_col, strain_col = stress_cols[0], strain_cols[0]
            stress_unit = extract_unit(stress_col)
            strain_unit = extract_unit(strain_col)

            stress_corr_name = f"Stress Corrected{f' ({stress_unit})' if stress_unit else ''}"
            strain_corr_name = f"Strain Corrected{f' ({strain_unit})' if strain_unit else ''}"

            # Apply corrections
            df[stress_corr_name] = df[stress_col] - df[stress_col].iloc[0]
            try:
                in_range_mask = (df[stress_corr_name] >= 0.001) & (df[stress_corr_name] <= 0.01)
                in_range_indices = df[stress_corr_name][in_range_mask].index
                if len(in_range_indices) > 0:
                    zero_index = in_range_indices[0]  # First index in the range
                else:
                    diff = (df[stress_corr_name] - 0.001).abs()
                    zero_index = diff.idxmin()
            except Exception:
                zero_index = df[stress_corr_name].idxmin()

            zero_strain = df[strain_col].iloc[zero_index]
            df[strain_corr_name] = df[strain_col] - zero_strain

            # Optionally write to disk
            if path and os.path.isfile(path):
                try:
                    df.to_csv(path, index=False)
                except Exception as e:
                    print(f"❌ Failed to write updated CSV: {e}")

        else:
            print("⚠️ Could not uniquely identify stress/strain columns for correction.")

        return df
    return cb.condense(_inner)

def fit_modulus_from_df(
    df,
    fit_range=None,
    scan_min=None,
    scan_max=None,
    best_window=True
):
    """
    Finds the modulus of elasticity by linear fit over `fit_range` strain window.
    If best_window=True, scans all windows of size `fit_range` between scan_min and scan_max.
    Returns dict with modulus, intercept, R², fit_x, fit_y, and fit_range used.
    """
    # Find corrected columns
    strain_cols = [c for c in df.columns if c.lower().startswith("strain corrected")]
    stress_cols = [c for c in df.columns if c.lower().startswith("stress corrected")]
    if not strain_cols or not stress_cols:
        print("❌ Corrected columns not found.")
        return None

    strain_col = strain_cols[0]
    stress_col = stress_cols[0]

    x = df[strain_col].values
    y = df[stress_col].values

    # Remove NaNs
    valid = np.isfinite(x) & np.isfinite(y)
    x = x[valid]
    y = y[valid]

    if best_window and fit_range is not None:
        if scan_min is None:
            scan_min = 0
        if scan_max is None:
            scan_max = np.nanmax(x) if len(x) else 0.1

        best_r2 = -np.inf
        best_result = None

        scan_starts = np.arange(scan_min, scan_max - fit_range + 1e-8, fit_range/25)
        for start in scan_starts:
            end = start + fit_range
            mask = (x >= start) & (x <= end)
            if np.count_nonzero(mask) < 2:
                continue
            x_fit = x[mask]
            y_fit = y[mask]
            # Remove NaNs
            good = np.isfinite(x_fit) & np.isfinite(y_fit)
            if np.count_nonzero(good) < 2:
                continue
            x_fit = x_fit[good]
            y_fit = y_fit[good]

            coeffs = np.polyfit(x_fit, y_fit, 1)
            a, b = coeffs
            y_pred = np.polyval(coeffs, x_fit)
            ss_res = np.sum((y_fit - y_pred) ** 2)
            ss_tot = np.sum((y_fit - np.mean(y_fit)) ** 2)
            r2 = 1 - ss_res / ss_tot if ss_tot > 0 else np.nan
            if r2 > best_r2:
                best_r2 = r2
                best_result = {
                    'modulus': a,
                    'intercept': b,
                    'r2': r2,
                    'fit_x': x_fit,
                    'fit_y': y_pred,
                    'fit_range': (start, end)
                }
        return best_result

    else:
        # Classic: single window from 0 to fit_range
        if fit_range is None:
            fit_range = 5  # default 5%
        mask = (x >= 0) & (x <= fit_range)
        if np.count_nonzero(mask) < 2:
            print(f"❌ No data with 0 <= strain <= {fit_range}.")
            return None
        x_fit = x[mask]
        y_fit = y[mask]

        valid = np.isfinite(x_fit) & np.isfinite(y_fit)
        if np.count_nonzero(valid) < 2:
            print("❌ Not enough points for modulus fit.")
            return None
        x_fit = x_fit[valid]
        y_fit = y_fit[valid]

        coeffs = np.polyfit(x_fit, y_fit, 1)
        a, b = coeffs
        y_pred = np.polyval(coeffs, x_fit)
        ss_res = np.sum((y_fit - y_pred) ** 2)
        ss_tot = np.sum((y_fit - np.mean(y_fit)) ** 2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else np.nan

        return {
            'modulus': a,
            'intercept': b,
            'r2': r2,
            'fit_x': x_fit,
            'fit_y': y_pred,
            'fit_range': (0, fit_range)
        }

def print_modulus_summary_df(
    df,
    fit_range=None,
    scan_min=None,
    scan_max=None,
    best_window=True
):
    """
    Computes and stores modulus and R² in df.attrs['modulus_analysis'], returns one-row DataFrame summary.
    Uses best window search if best_window=True, else classic fit.
    """
    result = fit_modulus_from_df(
        df,
        fit_range=fit_range,
        scan_min=scan_min,
        scan_max=scan_max,
        best_window=best_window
    )
    row = {}
    analysis = {}

    if result:
        row['Elastic Modulus'] = result['modulus']
        row['Modulus (fit R²)'] = result['r2']
        analysis['modulus'] = result
    else:
        row['Elastic Modulus'] = pd.NA
        row['Modulus (fit R²)'] = pd.NA
        analysis['modulus'] = None

    df.attrs["modulus_analysis"] = analysis
    summary_df = pd.DataFrame([row])
    return summary_df

def moe_numpy_to_list(obj):
    if isinstance(obj, dict):
        return {k: moe_numpy_to_list(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [moe_numpy_to_list(i) for i in obj]
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    else:
        return obj

def _process_file_modulus_parallel(row, fit_range, scan_min, scan_max, best_window, overwrite_cache):
    """Worker function used by batch_process_folder when parallel=True."""
    path = row["Full Path"]
    json_path = path + ".modulus.json"
    analysis = None

    if os.path.exists(json_path) and not overwrite_cache:
        try:
            with open(json_path, "r") as f:
                analysis = json.load(f)
        except Exception:
            analysis = None

    if analysis is None:
        df = cb.load_and_process_csv(path)
        if df is None or df.empty:
            return (row.name, None, None)
        try:
            print_modulus_summary_df(df, fit_range=fit_range,
                                     scan_min=scan_min, scan_max=scan_max,
                                     best_window=best_window)
            analysis = df.attrs.get('modulus_analysis', {})
            to_save = moe_numpy_to_list(analysis)
            with open(json_path, "w") as f:
                json.dump(to_save, f)
        except Exception:
            return (row.name, None, None)

    if analysis and analysis.get("modulus"):
        return (row.name,
                analysis["modulus"].get("modulus", pd.NA),
                analysis["modulus"].get("r2", pd.NA))
    return (row.name, None, None)


def batch_process_folder(
    target_folder,
    fit_range=0.05,
    scan_min=None,
    scan_max=None,
    best_window=True,
    overwrite_cache=False,
    parallel=False,
    max_workers=8,
):
    """
    Processes all CSV files in the target folder recursively.
    If a modulus result file exists for a CSV, loads it unless overwrite_cache is True.
    Saves new modulus results as a sidecar JSON file next to each CSV.
    Returns df_index with modulus columns filled.

    Parameters
    ----------
    parallel : bool
        If True, use a ThreadPoolExecutor for concurrent processing.
        Faster for large datasets but suppresses per-file progress output.
    max_workers : int
        Number of worker threads when parallel=True.
    """
    def _batch_inner():
        df_index = cb.build_df_index(target_folder)
        if df_index is None or df_index.empty:
            print("❌ No CSVs found for processing.")
            return None

        total = len(df_index)
        _prog = widgets.IntProgress(value=0, min=0, max=total, description='Processing:',
                                    bar_style='info', layout=widgets.Layout(width='80%'))
        _prog_label = widgets.Label(value=f'0 / {total} files')
        display(widgets.HBox([_prog, _prog_label]))

        # Add analysis columns (if not present)
        for col in ["Elastic Modulus", "Modulus (fit R²)"]:
            if col not in df_index.columns:
                df_index[col] = pd.NA

        _i = 0
        for idx, row in df_index.iterrows():
            path = row["Full Path"]
            _i += 1
            _prog.value = _i
            _prog_label.value = f'{_i} / {total} — {os.path.basename(path)}'
            if not os.path.exists(path):
                print(f"⚠️ Skipping: File not found: {path}")
                continue

            json_path = path + ".modulus.json"
            analysis = None
            cache_valid = False
            
            if os.path.exists(json_path) and not overwrite_cache:
                try:
                    with open(json_path, "r") as f:
                        analysis = json.load(f)
                    print(f"ℹ️ Loaded existing modulus for: {os.path.basename(path)}")
                    cache_valid = True
                except Exception as e:
                    print(f"⚠️ Error reading {json_path}: {e}")
                    # Remove the corrupted file so it will be recalculated
                    try:
                        os.remove(json_path)
                        print(f"⚠️ Removed corrupt JSON: {json_path}")
                    except Exception as remove_e:
                        print(f"❌ Could not remove corrupt JSON: {remove_e}")
                    analysis = None  # Make sure we recalculate

            if not cache_valid:
                # Do fresh calculation if not cached or if file was corrupt, or if overwriting
                df = cb.load_and_process_csv(path)
                if df is None or df.empty:
                    print(f"⚠️ Skipping (empty or error): {path}")
                    continue

                try:
                    summary_df = print_modulus_summary_df(
                        df,
                        fit_range=fit_range,
                        scan_min=scan_min,
                        scan_max=scan_max,
                        best_window=best_window
                    )
                    analysis = df.attrs.get('modulus_analysis', {})
                except Exception as e:
                    print(f"⚠️ Error processing {path}: {e}")
                    continue

                # --- Save new results to JSON with robust error checking ---
                try:
                    to_save = moe_numpy_to_list(analysis)
                    with open(json_path, "w") as f:
                        json.dump(to_save, f)
                        f.flush()
                        os.fsync(f.fileno())
                    if os.path.isfile(json_path) and os.path.getsize(json_path) > 0:
                        print(f"✅ Saved modulus to: {json_path}")
                    else:
                        print(f"❌ Save failed: file missing or empty: {json_path}")
                    # Optional: Read back to confirm
                    try:
                        with open(json_path, "r") as fcheck:
                            data_check = json.load(fcheck)
                        print(f"✅ JSON save/read roundtrip success for {json_path}")
                    except Exception as e:
                        print(f"❌ Error reading back saved JSON: {json_path} ({e})")
                except Exception as e:
                    print(f"❌ Failed to save JSON file {json_path}: {e}")
                    continue

            # Write results into df_index
            if analysis and analysis.get("modulus"):
                df_index.at[idx, "Elastic Modulus"] = analysis["modulus"].get("modulus", pd.NA)
                df_index.at[idx, "Modulus (fit R²)"] = analysis["modulus"].get("r2", pd.NA)

        print(f"✅ Completed batch processing for {len(df_index)} file(s).")
        return df_index

    if parallel:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        def _batch_parallel():
            df_index = cb.build_df_index(target_folder)
            if df_index is None or df_index.empty:
                print("❌ No CSVs found for processing.")
                return None
            for col in ["Elastic Modulus", "Modulus (fit R²)"]:
                if col not in df_index.columns:
                    df_index[col] = pd.NA
            futures = {}
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                for _, row in df_index.iterrows():
                    if not os.path.exists(row["Full Path"]):
                        continue
                    fut = executor.submit(
                        _process_file_modulus_parallel, row,
                        fit_range, scan_min, scan_max, best_window, overwrite_cache)
                    futures[fut] = row.name
                for fut in as_completed(futures):
                    idx, modulus, r2 = fut.result()
                    if idx is not None and modulus is not None:
                        df_index.at[idx, "Elastic Modulus"] = modulus
                        df_index.at[idx, "Modulus (fit R²)"] = r2
            for col in ["Elastic Modulus", "Modulus (fit R²)"]:
                if col in df_index.columns:
                    df_index[col] = pd.to_numeric(df_index[col], errors='coerce')
            print(f"✅ Completed batch processing for {len(df_index)} file(s) [parallel].")
            return df_index
        return cb.condense(_batch_parallel)

    # Use cb.condense to suppress/condense duplicate warning lines
    return cb.condense(_batch_inner)

def summarize_by_group_interactive(df_index, display_output=True):
    """
    Summarizes df_index by Specimen Group with mean and std (Elastic Modulus only),
    and provides an interactive dropdown to explore individual file entries per group.
    Includes buttons to export the group-averaged summary or the selected group's DataFrame.
    """
    if df_index is None or df_index.empty or "Specimen Group" not in df_index.columns:
        print("❌ Invalid df_index: missing or empty.")
        if not display_output:
            return pd.DataFrame(), pd.DataFrame()
        return

    numeric_cols = ["Elastic Modulus", "Modulus (fit R²)"]
    numeric_cols = [col for col in numeric_cols if col in df_index.columns]
    if not numeric_cols:
        print("❌ No numeric analysis columns present in df_index.")
        if not display_output:
            return pd.DataFrame(), pd.DataFrame()
        return

    df_index[numeric_cols] = df_index[numeric_cols].apply(pd.to_numeric, errors='coerce')

    # Means
    means = df_index.groupby("Specimen Group")[numeric_cols].mean(numeric_only=True)
    # Only calculate std for Elastic Modulus
    std = df_index.groupby("Specimen Group")["Elastic Modulus"].std(numeric_only=True).to_frame()
    std = std.rename(columns={"Elastic Modulus": "Elastic Modulus (std)"})

    summary_df = pd.concat([means, std], axis=1).reset_index()
    summary_df = summary_df.round(4)

    unique_groups = sorted(df_index["Specimen Group"].dropna().unique())

    if not display_output:
        if unique_groups:
            first_group = unique_groups[0]
            initial_group_df = df_index[df_index["Specimen Group"] == first_group].copy()
        else:
            initial_group_df = pd.DataFrame()
        return summary_df, initial_group_df

    print("📊 Group-Averaged Modulus of Elasticity (with Std Dev):")
    display(summary_df)

    if unique_groups:
        group_dropdown = widgets.Dropdown(
            options=unique_groups,
            description="Group:",
            layout=widgets.Layout(width='50%')
        )
        output_table = widgets.Output()

        export_summary_btn = widgets.Button(description="⬇️ Export Group-Averaged CSV", layout=widgets.Layout(width='auto'))
        export_group_btn = widgets.Button(description="⬇️ Export Selected Group CSV", layout=widgets.Layout(width='auto'))
        download_link = widgets.HTML("")

        def get_download_link(df, filename):
            csv_buffer = io.StringIO()
            df.to_csv(csv_buffer, index=False)
            b64 = base64.b64encode(csv_buffer.getvalue().encode()).decode()
            href = f'<a download="{filename}" href="data:text/csv;base64,{b64}">Click to download: {filename}</a>'
            return href

        def on_export_summary_clicked(_):
            download_link.value = get_download_link(summary_df, "group_averaged_modulus.csv")

        def on_export_group_clicked(_):
            group = group_dropdown.value
            group_df = df_index[df_index["Specimen Group"] == group].copy()
            download_link.value = get_download_link(group_df, f"modulus_results_{group}.csv")

        export_summary_btn.on_click(on_export_summary_clicked)
        export_group_btn.on_click(on_export_group_clicked)

        def show_group_table(change):
            output_table.clear_output()
            group = change["new"]
            with output_table:
                group_df = df_index[df_index["Specimen Group"] == group].copy()
                display(group_df)

        group_dropdown.observe(show_group_table, names="value")
        display(widgets.HBox([export_summary_btn, export_group_btn, download_link]))
        display(widgets.VBox([group_dropdown, output_table]))
        show_group_table({"new": group_dropdown.value})
    else:
        print("No specimen groups found in df_index.")

def export_all_moe_svg(
    target_folder,
    output_folder=None,
    fit_range=None,
    scan_min=None,
    scan_max=None,
    best_window=True,
    show_fit=True,
    xlim=(0, 15),
    ylim=None,
    y_margin=1.25
):
    """
    Processes every CSV in target_folder and saves one SVG per specimen to
    output_folder. Files are named <specimen>_moe.svg.

    Auto-scale behaviour for y-axis (ylim=None, the default):
      y_max = max(stress within [xlim[0], xlim[1]]) * y_margin (default 1.25)
    X-axis is fixed to xlim (default (0, 15)). Pass an explicit ylim tuple
    to override per-plot auto-scaling.

    Parameters
    ----------
    target_folder : str
        Folder to search recursively for CSV files.
    output_folder : str, optional
        Destination folder for the SVGs. Defaults to ./output/ relative to cwd.
    xlim : tuple of (float, float)
        Strain axis limits, e.g. (0, 25). Applied to every exported SVG.
    ylim : tuple of (float, float), optional
        Stress axis limits. When None (default), each plot auto-scales from data.
    y_margin : float
        Multiplier applied to the auto-scaled y_max (default 1.25).
    fit_range, scan_min, scan_max, best_window, show_fit :
        Same parameters as plot_moe_from_df.
    """
    if output_folder is None:
        output_folder = os.path.join(os.getcwd(), "output")
    os.makedirs(output_folder, exist_ok=True)

    df_index = cb.build_df_index(target_folder)
    if df_index is None or df_index.empty:
        print("❌ No CSVs found in target folder.")
        return []

    total = len(df_index)
    _prog = widgets.IntProgress(value=0, min=0, max=total, description='Exporting:',
                                bar_style='info', layout=widgets.Layout(width='80%'))
    _prog_label = widgets.Label(value=f'0 / {total} files')
    display(widgets.HBox([_prog, _prog_label]))

    saved = []
    for i, (_, row) in enumerate(df_index.iterrows()):
        path = row["Full Path"]
        label = row.get("File Name", os.path.basename(path))
        stem = os.path.splitext(label)[0]
        _prog.value = i + 1
        _prog_label.value = f'{i + 1} / {total} — {label}'
        if not os.path.exists(path):
            print(f"⚠️ Skipping (not found): {path}")
            continue
        try:
            df = cb.load_and_process_csv(path)
            if df is None or df.empty:
                print(f"⚠️ Skipping (empty): {path}")
                continue

            stress_cols = [c for c in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", c)]
            strain_cols = [c for c in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", c)]
            if not stress_cols or not strain_cols:
                print(f"⚠️ Skipping (no corrected columns): {label}")
                continue

            x_col, y_col = strain_cols[0], stress_cols[0]
            df[x_col] = pd.to_numeric(df[x_col], errors='coerce')
            df[y_col] = pd.to_numeric(df[y_col], errors='coerce')
            df_clean = df[[x_col, y_col]].dropna()
            if df_clean.empty:
                continue

            # Extract stress units from column name, e.g. "Stress Corrected (MPa)" → "MPa"
            _u = re.search(r'\(([^)]+)\)', y_col)
            stress_units = _u.group(1) if _u else ''

            fit_result = fit_modulus_from_df(
                df_clean,
                fit_range=fit_range,
                scan_min=scan_min,
                scan_max=scan_max,
                best_window=best_window
            )

            # --- Draw individual figure ---
            fig, ax = plt.subplots(figsize=(10, 7))
            fig.patch.set_facecolor('white')
            ax.set_facecolor('white')

            ax.plot(df_clean[x_col], df_clean[y_col],
                    color='#4c72b0', lw=1.5, alpha=0.9, label=stem)

            if fit_result and show_fit:
                def sig(x, sig=3):
                    if x == 0 or pd.isnull(x):
                        return "0"
                    return f"{x:.{sig}g}"
                moe_str = sig(fit_result['modulus'])
                r2_str = sig(fit_result['r2'])
                fit_bounds = ""
                if 'fit_range' in fit_result:
                    fit_bounds = f" [{fit_result['fit_range'][0]:.3f}–{fit_result['fit_range'][1]:.3f}]"
                units_str = (' ' + stress_units) if stress_units else ''
                ax.plot(
                    fit_result['fit_x'], fit_result['fit_y'],
                    '--', color='red', lw=2,
                    label=f"MOE={moe_str}{units_str}, R²={r2_str}{fit_bounds}"
                )

            ax.set_xlabel(x_col, fontsize=16)
            ax.set_ylabel(y_col, fontsize=16)
            ax.set_title(stem, fontsize=16)
            ax.set_xlim(xlim)
            if ylim is not None:
                ax.set_ylim(ylim)
            else:
                _x = df_clean[x_col].values; _y = df_clean[y_col].values
                _mask = (_x >= xlim[0]) & (_x <= xlim[1]) & np.isfinite(_y)
                _max_y = float(np.nanmax(_y[_mask])) if np.any(_mask) else float(np.nanmax(_y[np.isfinite(_y)]))
                ax.set_ylim(0.0, _max_y * y_margin)
            ax.grid(True, alpha=0.3)
            for spine in ['top', 'right']:
                ax.spines[spine].set_visible(False)
            for spine in ['left', 'bottom']:
                ax.spines[spine].set_color('black')
                ax.spines[spine].set_linewidth(1.0)
            ax.legend(fontsize=11, loc='upper left')

            plt.tight_layout()
            svg_path = os.path.join(output_folder, f"{stem}_moe.svg")
            fig.savefig(svg_path, format='svg')
            plt.close(fig)
            saved.append(svg_path)

        except Exception as e:
            print(f"❌ Error processing {label}: {e}")
            continue

    print(f"✅ Saved {len(saved)} SVG(s) to: {output_folder}")
    return saved

def export_groups_moe_svg(
    target_folder,
    output_folder=None,
    fit_range=None,
    scan_min=None,
    scan_max=None,
    best_window=True,
    show_fit=True,
    xlim=(0, 15),
    ylim=None,
    y_margin=1.25
):
    """
    Processes every CSV in target_folder, groups specimens by subfolder
    (Specimen Group), and saves one SVG per group. Each SVG shows all
    specimens in that group overlaid on a single figure with their individual
    MOE fit lines. Files are named <group>_moe.svg.

    Auto-scale behaviour for y-axis (ylim=None, the default):
      y_max = max(stress within [xlim[0], xlim[1]] across all group specimens)
              * y_margin (default 1.25)
    X-axis is fixed to xlim (default (0, 15)). Pass an explicit ylim tuple
    to use the same limits for every group.

    Parameters
    ----------
    target_folder : str
        Folder to search recursively for CSV files.
    output_folder : str, optional
        Destination folder for the SVGs. Defaults to ./output/ relative to cwd.
    xlim : tuple of (float, float)
        Strain axis limits, e.g. (0, 25). Applied to every exported SVG.
    ylim : tuple of (float, float), optional
        Stress axis limits. When None (default), each group auto-scales from data.
    y_margin : float
        Multiplier applied to the auto-scaled y_max (default 1.25).
    fit_range, scan_min, scan_max, best_window, show_fit :
        Same parameters as plot_moe_from_df.
    """
    if output_folder is None:
        output_folder = os.path.join(os.getcwd(), "output")
    os.makedirs(output_folder, exist_ok=True)

    df_index = cb.build_df_index(target_folder)
    if df_index is None or df_index.empty:
        print("❌ No CSVs found in target folder.")
        return []

    groups = sorted(df_index["Specimen Group"].dropna().unique())
    total = len(groups)
    _prog = widgets.IntProgress(value=0, min=0, max=total, description='Exporting:',
                                bar_style='info', layout=widgets.Layout(width='80%'))
    _prog_label = widgets.Label(value=f'0 / {total} groups')
    display(widgets.HBox([_prog, _prog_label]))

    cmap = cm.get_cmap('tab10')
    saved = []

    for g_i, group_name in enumerate(groups):
        _prog.value = g_i + 1
        _prog_label.value = f'{g_i + 1} / {total} — {group_name}'
        group_rows = df_index[df_index["Specimen Group"] == group_name]

        fig, ax = plt.subplots(figsize=(10, 7))
        fig.patch.set_facecolor('white')
        ax.set_facecolor('white')

        any_plotted = False
        x_col, y_col = 'Strain (corrected)', 'Stress (corrected)'
        group_max_y = 0.0

        for j, (_, row) in enumerate(group_rows.iterrows()):
            path = row["Full Path"]
            label = row.get("File Name", os.path.basename(path))
            stem = os.path.splitext(label)[0]
            if not os.path.exists(path):
                print(f"⚠️ Skipping (not found): {path}")
                continue
            try:
                df = cb.load_and_process_csv(path)
                if df is None or df.empty:
                    continue

                stress_cols = [c for c in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", c)]
                strain_cols = [c for c in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", c)]
                if not stress_cols or not strain_cols:
                    continue

                x_col, y_col = strain_cols[0], stress_cols[0]
                df[x_col] = pd.to_numeric(df[x_col], errors='coerce')
                df[y_col] = pd.to_numeric(df[y_col], errors='coerce')
                df_clean = df[[x_col, y_col]].dropna()
                if df_clean.empty:
                    continue

                # Extract stress units from column name, e.g. "Stress Corrected (MPa)" → "MPa"
                _u = re.search(r'\(([^)]+)\)', y_col)
                stress_units = _u.group(1) if _u else ''

                color = cmap(j % 10)
                ax.plot(df_clean[x_col], df_clean[y_col],
                        color=color, lw=1.5, alpha=0.8, label=stem)
                any_plotted = True
                _gx = df_clean[x_col].values; _gy = df_clean[y_col].values
                _gmask = (_gx >= xlim[0]) & (_gx <= xlim[1]) & np.isfinite(_gy)
                if np.any(_gmask):
                    group_max_y = max(group_max_y, float(np.nanmax(_gy[_gmask])))

                fit_result = fit_modulus_from_df(
                    df_clean, fit_range=fit_range,
                    scan_min=scan_min, scan_max=scan_max,
                    best_window=best_window
                )
                if fit_result and show_fit:
                    def sig(x, sig=3):
                        if x == 0 or pd.isnull(x):
                            return "0"
                        return f"{x:.{sig}g}"
                    moe_str = sig(fit_result['modulus'])
                    r2_str = sig(fit_result['r2'])
                    fit_bounds = ""
                    if 'fit_range' in fit_result:
                        fit_bounds = f" [{fit_result['fit_range'][0]:.3f}–{fit_result['fit_range'][1]:.3f}]"
                    units_str = (' ' + stress_units) if stress_units else ''
                    ax.plot(
                        fit_result['fit_x'], fit_result['fit_y'],
                        '--', color=color, lw=1.5,
                        label=f"{stem} MOE={moe_str}{units_str}, R²={r2_str}{fit_bounds}"
                    )

            except Exception as e:
                print(f"❌ Error processing {label}: {e}")
                continue

        if not any_plotted:
            print(f"⚠️ No data for group: {group_name}")
            plt.close(fig)
            continue

        ax.set_xlabel(x_col, fontsize=16)
        ax.set_ylabel(y_col, fontsize=16)
        ax.set_title(group_name, fontsize=16)
        ax.set_xlim(xlim)
        _grp_ylim = ylim if ylim is not None else (0.0, group_max_y * y_margin if group_max_y > 0 else 1.0)
        ax.set_ylim(_grp_ylim)
        ax.grid(True, alpha=0.3)
        for spine in ['top', 'right']:
            ax.spines[spine].set_visible(False)
        for spine in ['left', 'bottom']:
            ax.spines[spine].set_color('black')
            ax.spines[spine].set_linewidth(1.0)
        ax.legend(fontsize=9, loc='upper left')

        plt.tight_layout()
        safe_name = group_name.replace('/', '_').replace('\\', '_')
        svg_path = os.path.join(output_folder, f"{safe_name}_moe.svg")
        fig.savefig(svg_path, format='svg')
        plt.close(fig)
        saved.append(svg_path)

    print(f"✅ Saved {len(saved)} group SVG(s) to: {output_folder}")
    return saved

def plot_elastic_modulus_by_group(df, group_col='Specimen Group', value_col='Elastic Modulus'):
    """
    Plots a boxplot of `value_col` grouped by `group_col` using a fivethirtyeight style.

    Parameters:
    - df (pd.DataFrame): The input DataFrame containing group and value columns.
    - group_col (str): Column name representing the group (e.g., 'Specimen Group').
    - value_col (str): Column name for the values to plot (e.g., 'Elastic Modulus').
    """
    plt.style.use('fivethirtyeight')

    groups = df[group_col].unique()
    data = [
        df[df[group_col] == group][value_col].dropna().values
        for group in groups
    ]

    fig, ax = plt.subplots(figsize=(20, 7))  # Wider plot
    bp = ax.boxplot(data, labels=groups, patch_artist=True)

    ax.set_ylabel(value_col)
    ax.set_xlabel(group_col)
    ax.set_title(f'{value_col} by {group_col}')

    plt.xticks(rotation=90)
    plt.tight_layout()
    plt.show()
