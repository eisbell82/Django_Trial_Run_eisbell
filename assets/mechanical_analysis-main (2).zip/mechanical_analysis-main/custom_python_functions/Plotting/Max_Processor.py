import numpy as np
import pandas as pd
import warnings
import os
import json
import Plotting.Polyfit_Processor as pp
import Plotting.Single_Plot as sp
import Plotting.Multi_Plot as mult
import Utility.csv_file_browser as cb
import ipywidgets as widgets
from IPython.display import display, clear_output
import sys
import io
from collections import Counter
import base64
import matplotlib.pyplot as plt
import re


def correct_stress_and_strain(df, path=None, overwrite=True):
    """
    Adds or overwrites 'Stress Corrected (unit)' columns.
    If overwrite=True, deletes any previous corrected columns before writing new.
    """
    def _inner():
        def extract_unit(col):
            # Extract anything in parentheses at the end
            match = re.search(r'\(([^)]+)\)\s*$', col)
            if match:
                return match.group(1).strip()
            return None

        original_columns = df.columns.tolist()
        # Find existing corrected columns
        stress_corr_col = next((col for col in original_columns if col.lower().startswith("stress corrected")), None)
        strain_corr_col = next((col for col in original_columns if col.lower().startswith("strain corrected")), None)
        already_exists = [c for c in [stress_corr_col, strain_corr_col] if c]

        if already_exists and not overwrite:
            return df

        # Remove existing corrected columns if overwriting
        if overwrite:
            for col in [stress_corr_col, strain_corr_col]:
                if col and col in df.columns:
                    df.drop(columns=col, inplace=True)

        # Identify original columns and units
        original_columns = df.columns.tolist()
        stress_cols = [col for col in original_columns if "stress" in col.lower() and "corrected" not in col.lower()]
        strain_cols = [col for col in original_columns if "strain" in col.lower() and "corrected" not in col.lower()]

        if len(stress_cols) == 1 and len(strain_cols) == 1:
            stress_col, strain_col = stress_cols[0], strain_cols[0]
            stress_unit = extract_unit(stress_col)
            strain_unit = extract_unit(strain_col)

            stress_corr_name = f"Stress Corrected{f' ({stress_unit})' if stress_unit else ''}"
            strain_corr_name = f"Strain Corrected{f' ({strain_unit})' if strain_unit else ''}"

            # Apply corrections
            df[stress_corr_name] = df[stress_col] - df[stress_col].iloc[0]
            try:
                in_range_mask = (df[stress_corr_name] >= 0.001) & (df[stress_corr_name] <= 0.01)
                in_range_indices = df[stress_corr_name][in_range_mask].index
                if len(in_range_indices) > 0:
                    zero_index = in_range_indices[0]  # First index in the range
                else:
                    diff = (df[stress_corr_name] - 0.001).abs()
                    zero_index = diff.idxmin()
            except Exception:
                zero_index = df[stress_corr_name].idxmin()

            zero_strain = df[strain_col].iloc[zero_index]
            df[strain_corr_name] = df[strain_col] - zero_strain

            # Optionally write to disk
            if path and os.path.isfile(path):
                try:
                    df.to_csv(path, index=False)
                except Exception as e:
                    print(f"❌ Failed to write updated CSV: {e}")

        else:
            print("⚠️ Could not uniquely identify stress/strain columns for correction.")

        return df
    return cb.condense(_inner)



def record_minima_and_zeros(df):
    """
    Adds second derivative minima and zero-crossing DataFrames to df.attrs['curve_analysis'].
    """

    if df is None or df.empty or not hasattr(df, "attrs"):
        print("❌ Invalid DataFrame input to record_minima_and_zeros.")
        return

    strain_col = df.attrs.get('strain_col')
    x = df.attrs.get('x_plot', None)
    if x is None:
        x = df.attrs.get('x', None)
    if strain_col is None or x is None:
        print("❌ strain_col or x values not found in df.attrs.")
        return


    # Accept any d2 column name
    d2_cols = [col for col in df.columns if "Second Derivative" in col]
    if not d2_cols:
        print("❌ No second derivative column found.")
        return
    d2_fit = df[d2_cols[0]].values

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)

        d3_fit = np.gradient(d2_fit, x)
        zero_crossings = np.where(np.diff(np.sign(d3_fit)))[0]
        valid_minima_mask = (d3_fit[zero_crossings] < 0) & (d3_fit[zero_crossings + 1] > 0)
        valid_indices = zero_crossings[valid_minima_mask]

        minima_df = pd.DataFrame({
            'strain': x[valid_indices],
            'd2_fit': d2_fit[valid_indices]
        })

        d2_zero_crossings = np.where(np.diff(np.signbit(d2_fit)))[0]
        zero_df = pd.DataFrame({
            'strain': x[d2_zero_crossings + 1],
            'd2_fit': d2_fit[d2_zero_crossings + 1]
        })

    # Attach to attrs in curve_analysis dict (merge if exists)
    curve_analysis = df.attrs.get("curve_analysis", {})
    curve_analysis['second_derivative_minima'] = minima_df
    curve_analysis['second_derivative_zeros'] = zero_df
    df.attrs["curve_analysis"] = curve_analysis

def label_zero_crossing_directions(df):
    """
    Labels the direction of each zero crossing in the second derivative and stores in df.attrs['curve_analysis']['zero_directions'].
    """

    try:
        # Extract zero crossings DataFrame from attrs
        curve_analysis = df.attrs.get('curve_analysis', {})
        zero_df = curve_analysis.get('second_derivative_zeros', pd.DataFrame())
        if zero_df.empty:
            return

        x = df[df.attrs['strain_col']].values
        d2_cols = [col for col in df.columns if "Second Derivative" in col]
        if not d2_cols:
            print("❌ No second derivative column found.")
            return
        d2 = df[d2_cols[0]].values

        directions = []
        for _, row in zero_df.iterrows():
            z = row['strain']
            idx = np.searchsorted(x, z)
            if 0 < idx < len(d2) - 1:
                if d2[idx - 1] < 0 and d2[idx] > 0:
                    direction = 'Neg-to-Pos'
                elif d2[idx - 1] > 0 and d2[idx] < 0:
                    direction = 'Pos-to-Neg'
                else:
                    direction = 'Flat'
            else:
                direction = 'Out of Bounds'
            directions.append({'strain': z, 'direction': direction})

        # Attach to curve_analysis in attrs
        curve_analysis['zero_directions'] = pd.DataFrame(directions)
        df.attrs['curve_analysis'] = curve_analysis

    except Exception as e:
        print(f"⚠️ Error in label_zero_crossing_directions: {e}")

def find_inflection_neg_to_pos(df):
    """
    Compute ALL inflections where d2 crosses negative -> positive (with interpolation),
    keep them in df.attrs['curve_analysis']['inflections_all'],
    then RETURN ONLY the one with the LARGEST fitted stress among those with strain <= 60.
    Returns {'strain': float, 'stress': float} or None.
    """
    MAX_STRAIN_FOR_SELECTION = 60.0

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)

            strain_col = df.attrs.get('strain_col')
            if not strain_col or strain_col not in df.columns:
                print("❌ Missing strain_col in df or df.attrs.")
                return None

            # Preferred: use a "Polynomial Fit" column; fallback to best_coeffs
            polyfit_cols = [c for c in df.columns if "Polynomial Fit" in c]
            polyfit_col = polyfit_cols[0] if polyfit_cols else None
            coeffs = df.attrs.get('best_coeffs', None)

            d2_cols = [c for c in df.columns if "Second Derivative" in c]
            if not d2_cols:
                print("❌ No 'Second Derivative' column found.")
                return None

            x = df[strain_col].to_numpy()
            d2 = df[d2_cols[0]].to_numpy()

            # Choose y_fit source
            if polyfit_col is not None:
                y_fit_src = df[polyfit_col].to_numpy()
            elif coeffs is not None:
                y_fit_src = np.polyval(np.array(coeffs), x)
            else:
                print("❌ Need either a 'Polynomial Fit' column or 'best_coeffs' in attrs.")
                return None

            # Ensure increasing x (sort if needed)
            if np.any(np.diff(x) < 0):
                order = np.argsort(x)
                x, d2, y_fit_src = x[order], d2[order], y_fit_src[order]

            # Clean NaNs/Infs
            mask = np.isfinite(x) & np.isfinite(d2) & np.isfinite(y_fit_src)
            x, d2, y_fit_src = x[mask], d2[mask], y_fit_src[mask]
            if x.size < 2:
                return None

            # Detect neg -> pos using signbit
            sb = np.signbit(d2)  # True where d2 < 0
            cand_idx = np.where(sb[:-1] & ~sb[1:])[0]
            if cand_idx.size == 0:
                return None

            # Interpolate all zero-crossings (ALL inflections), keep strain >= 0
            all_inflections = []  # list of dicts: {'strain', 'stress'}
            for i in cand_idx:
                x0, x1 = x[i], x[i + 1]
                y0, y1 = d2[i], d2[i + 1]
                if not (np.isfinite(x0) and np.isfinite(x1) and np.isfinite(y0) and np.isfinite(y1)):
                    continue
                denom = (y1 - y0)
                if x1 == x0 or denom == 0:
                    continue

                t = -y0 / denom  # fraction from i to i+1 where d2 == 0
                if not (0.0 <= t <= 1.0):
                    continue

                x_zero = x0 + t * (x1 - x0)
                if x_zero < 0:
                    # still record the full set only if you want strictly all inflections, including negatives:
                    # here we skip negatives to match prior behavior; change if you want truly all.
                    continue

                yfit0, yfit1 = y_fit_src[i], y_fit_src[i + 1]
                y_zero = yfit0 + t * (yfit1 - yfit0)
                all_inflections.append({'strain': float(x_zero), 'stress': float(y_zero)})

            # Attach all found inflections to attrs (non-breaking addition)
            curve_analysis = df.attrs.get('curve_analysis', {})
            curve_analysis['inflections_all'] = all_inflections
            df.attrs['curve_analysis'] = curve_analysis

            if not all_inflections:
                return None

            # Selection step: only consider inflections with strain <= 60
            eligible = [pt for pt in all_inflections if pt['strain'] <= MAX_STRAIN_FOR_SELECTION]
            if not eligible:
                return None

            # Choose by largest stress; tie-break on largest strain
            best = max(eligible, key=lambda d: (d['stress'], d['strain']))
            return {'strain': float(np.round(best['strain'], 6)), 'stress': float(best['stress'])}

    except Exception as e:
        print(f"Error in find_inflection_neg_to_pos: {e}")
        return None

def find_yield_stress_point(df):
    """
    Finds the yield stress point (local maximum of the polynomial fit: first positive-to-negative zero crossing of dy/dx with highest stress)
    within the fit region specified in df.attrs['fit_region_min'] and ['fit_region_max'] if present (otherwise defaults to 0–50).
    Returns a dict: {'strain': ..., 'stress': ...}, or None if not found.
    """

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)

            strain_col = df.attrs.get('strain_col')
            polyfit_cols = [c for c in df.columns if "Polynomial Fit" in c]
            if not strain_col or not polyfit_cols:
                print("❌ Missing required columns in DataFrame.")
                return None

            x = df[strain_col].values
            y = df[polyfit_cols[0]].values
            dy = np.gradient(y, x)

            # Use fit region from attrs, or default to 0–50 if not present
            min_strain = df.attrs.get("fit_region_min", None)
            max_strain = df.attrs.get("fit_region_max", None)
            if min_strain is None or max_strain is None:
                min_strain, max_strain = 0, 50
                print("⚠️ fit_region_min and/or fit_region_max not found in DataFrame attrs. Defaulting max calculation to strain 0–50.")
            min_strain = max(min_strain, 0)  # yield stress only defined at positive strains

            zero_crossings = np.where(np.diff(np.sign(dy)))[0]
            maxima_indices = [i for i in zero_crossings if dy[i] > 0 and dy[i + 1] < 0]

            if not maxima_indices:
                return None

            # Filter maxima to desired strain range
            filtered_indices = [i for i in maxima_indices if min_strain <= x[i] <= max_strain]

            if filtered_indices:
                max_idx = max(filtered_indices, key=lambda i: y[i])
                return {
                    'strain': np.round(float(x[max_idx]), 4),
                    'stress': y[max_idx]
                }
            else:
                # No maxima in the specified region
                return None

    except Exception as e:
        print(f"Error in find_yield_stress_point: {e}")
        return None

#Alternative yield stress calc

def find_yield_stress_point_polyfit(df):
    """
    Analytically finds the yield stress point (maximum of the polynomial fit) using df.attrs['best_coeffs'],
    within the fit region specified in df.attrs['fit_region_min'] and ['fit_region_max']
    (defaults to 0–50 if not present).
    Returns a dict: {'strain': ..., 'stress': ...}, or None if not found.
    """
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)

            coeffs = df.attrs.get('best_coeffs', None)
            if coeffs is None:
                print("❌ No polynomial coefficients ('best_coeffs') found in DataFrame attrs.")
                return None
            coeffs = np.array(coeffs)

            # Get fit region or default
            min_strain = df.attrs.get("fit_region_min", 0)
            max_strain = df.attrs.get("fit_region_max", 50)
            if not ("fit_region_min" in df.attrs and "fit_region_max" in df.attrs):
                print("⚠️ fit_region_min and/or fit_region_max not found in DataFrame attrs. Defaulting max calculation to strain 0–50.")
            min_strain = max(min_strain, 0)  # yield stress only defined at positive strains

            # Find roots of derivative (stationary points)
            dcoeffs = np.polyder(coeffs)
            roots = np.roots(dcoeffs)
            roots = roots[np.isreal(roots)].real  # Only real roots

            # Restrict roots to within the fit region
            in_region = (roots >= min_strain) & (roots <= max_strain)
            region_roots = roots[in_region]

            # Evaluate polynomial at roots and at endpoints (in case max is at a boundary)
            candidates_x = list(region_roots)
            candidates_y = [np.polyval(coeffs, x) for x in region_roots]

            if not candidates_x:
                return None

            # Find max stress among all candidates
            max_idx = np.argmax(candidates_y)
            max_strain_val = float(candidates_x[max_idx])
            max_stress_val = float(candidates_y[max_idx])

            return {
                'strain': np.round(max_strain_val, 4),
                'stress': max_stress_val
            }

    except Exception as e:
        print(f"Error in find_yield_stress_point_polyfit: {e}")
        return None

def find_strongest_negative_curvature(df):
    """
    Finds the local minimum of the second derivative of the fit curve
    with the highest strain within 0 <= strain <= 50. Must be a true local minimum (d3 goes - to +).
    Returns a dict: {'strain', 'stress', 'curvature'}, or None.
    """
    try:
        d2_cols = [c for c in df.columns if "Second Derivative" in c]
        polyfit_cols = [c for c in df.columns if "Polynomial Fit" in c]
        strain_col = df.attrs.get('strain_col')
        x = df.attrs.get('x_plot')
        if x is None:
            x = df.attrs.get('x')

        if not d2_cols or not polyfit_cols or strain_col is None or x is None:
            print("❌ Missing required columns in DataFrame.")
            return None

        d2_fit = df[d2_cols[0]].values
        poly_fit = df[polyfit_cols[0]].values

        # Restrict to 0 <= strain <= 50
        mask = (x >= 0) & (x <= 50)
        if not np.any(mask):
            print("❌ No data with 0 <= strain <= 50.")
            return None

        x_masked = x[mask]
        d2_masked = d2_fit[mask]
        poly_fit_masked = poly_fit[mask]

        # Calculate third derivative
        d3_masked = np.gradient(d2_masked, x_masked)
        # Find local minima: third derivative crosses - to + (i.e., d3[i-1]<0 and d3[i]>0)
        minima_indices = np.where((d3_masked[:-1] < 0) & (d3_masked[1:] > 0))[0] + 1

        if minima_indices.size == 0:
            print("❌ No local minima of 2nd derivative in 0 <= strain <= 50.")
            return None

        # Pick the minimum with the highest strain
        min_idx = minima_indices[np.argmax(x_masked[minima_indices])]
        min_strain = x_masked[min_idx]
        min_d2_fit = d2_masked[min_idx]
        min_stress = poly_fit_masked[min_idx] if 0 <= min_idx < len(poly_fit_masked) else None

        return {
            'strain': float(min_strain),
            'stress': float(min_stress),
            'curvature': float(min_d2_fit)
        }

    except Exception as e:
        print(f"Error in find_strongest_negative_curvature: {e}")
        return None
        
def print_max_summary_df(df):
    """
    Computes and stores yield stress, inflection, and strongest curvature markers
    in df.attrs['curve_analysis'] and returns a one-row DataFrame summary.
    Never prints or displays—returns summary DataFrame only.
    """
    # Make sure minima/zeros are computed
    curve_analysis = df.attrs.get('curve_analysis', {})
    if 'second_derivative_minima' not in curve_analysis:
        record_minima_and_zeros(df)
        curve_analysis = df.attrs.get('curve_analysis', {})
    row = {}

    max1 = find_yield_stress_point_polyfit(df)
    if max1:
        max1 = {
            'strain': float(max1['strain']) if max1['strain'] is not None else None,
            'stress': float(max1['stress']) if max1['stress'] is not None else None,
        }
        row['Yield Stress (x)'] = max1['strain']
        row['Yield Stress (y)'] = max1['stress']
        curve_analysis['yield_stress'] = max1
    else:
        curve_analysis['yield_stress'] = {'strain': None, 'stress': None}

    max2 = find_inflection_neg_to_pos(df)
    if max2:
        max2 = {
            'strain': float(max2['strain']) if max2['strain'] is not None else None,
            'stress': float(max2['stress']) if max2['stress'] is not None else None,
        }
        row['Inflection (x)'] = max2['strain']
        row['Inflection (y)'] = max2['stress']
        curve_analysis['inflection'] = max2
    else:
        curve_analysis['inflection'] = {'strain': None, 'stress': None}

    # [DISABLED] Strongest curvature removed as a strength definition — uncomment to re-enable.
    # max3 = find_strongest_negative_curvature(df)
    # if max3:
    #     max3 = {
    #         'strain': float(max3['strain']) if max3['strain'] is not None else None,
    #         'stress': float(max3['stress']) if max3['stress'] is not None else None,
    #         'curvature': float(max3['curvature']) if max3['curvature'] is not None else None,
    #     }
    #     row['Strongest Curvature (x)'] = max3['strain']
    #     row['Strongest Curvature (y)'] = max3['stress']
    #     row['Curvature'] = max3['curvature']
    #     curve_analysis['strongest_curvature'] = max3
    # else:
    #     curve_analysis['strongest_curvature'] = {'strain': None, 'stress': None, 'curvature': None}

    # Attach all marker info to .attrs
    df.attrs["curve_analysis"] = curve_analysis

    summary_df = pd.DataFrame([row])
    return summary_df

def batch_process_folder(target_folder, markers=None, overwrite_cache=True):
    """
    Processes all CSV files in the target folder recursively.
    For each CSV, loads/cleans the data, computes key points,
    and returns a df_index with analysis columns filled.
    Prints condensed error/warning output using cb.condense.
    Caches curve analysis to .curve_analysis.json per CSV file.
    Set overwrite_cache=True to force recalculation.
    """
    if markers is None:
        # [DISABLED] "curvature" removed as a default strength marker — uncomment to re-enable.
        markers = {"max", "inflection"}  # , "curvature"
    def _batch_inner():
        df_index = cb.build_df_index(target_folder)
        if df_index is None or df_index.empty:
            print("❌ No CSVs found for processing.")
            return None

        total = len(df_index)
        _prog = widgets.IntProgress(value=0, min=0, max=total, description='Processing:',
                                    bar_style='info', layout=widgets.Layout(width='80%'))
        _prog_label = widgets.Label(value=f'0 / {total} files')
        display(widgets.HBox([_prog, _prog_label]))

        for col in [
            "Yield Stress (x)", "Yield Stress (y)",
            "Inflection (x)", "Inflection (y)",
            # [DISABLED] Strongest curvature columns removed as strength definitions — uncomment to re-enable.
            # "Strongest Curvature (x)", "Strongest Curvature (y)",
            # "Curvature"
        ]:
            if col not in df_index.columns:
                df_index[col] = pd.NA

        _i = 0
        for idx, row in df_index.iterrows():
            path = row["Full Path"]
            _i += 1
            _prog.value = _i
            _prog_label.value = f'{_i} / {total} — {os.path.basename(path)}'
            if not os.path.exists(path):
                print(f"⚠️ Skipping: File not found: {path}")
                continue

            json_path = path + ".curve_analysis.json"
            analysis = None
            cache_valid = False

            # Try cache, unless forced overwrite
            if os.path.exists(json_path) and not overwrite_cache:
                try:
                    with open(json_path, "r") as f:
                        analysis = json.load(f)
                    print(f"ℹ️ Loaded curve analysis cache for: {os.path.basename(path)}")
                    cache_valid = True
                except Exception as e:
                    print(f"⚠️ Error reading {json_path}: {e}")
                    try:
                        os.remove(json_path)
                        print(f"⚠️ Removed corrupt JSON: {json_path}")
                    except Exception as remove_e:
                        print(f"❌ Could not remove corrupt JSON: {remove_e}")
                    analysis = None

            if not cache_valid:
                # Process as normal if cache missing/invalid/overwritten
                df = cb.load_and_process_csv(path)
                if df is None or df.empty:
                    print(f"⚠️ Skipping (empty or error): {path}")
                    continue
                try:
                    df_fit = pp.find_and_fit(df, path, overwrite=overwrite_cache)
                    print_max_summary_df(df_fit)
                    analysis = df_fit.attrs.get('curve_analysis', {})
                except Exception as e:
                    print(f"⚠️ Error processing {path}: {e}")
                    continue
                # Save cache with robust serialization
                try:
                    to_save = max_json_safe(analysis)
                    with open(json_path, "w") as f:
                        json.dump(to_save, f)
                        f.flush()
                        os.fsync(f.fileno())
                    if os.path.isfile(json_path) and os.path.getsize(json_path) > 0:
                        print(f"✅ Saved curve analysis to: {json_path}")
                    else:
                        print(f"❌ Save failed: file missing or empty: {json_path}")
                    try:
                        with open(json_path, "r") as fcheck:
                            data_check = json.load(fcheck)
                        print(f"✅ JSON save/read roundtrip success for {json_path}")
                    except Exception as e:
                        print(f"❌ Error reading back saved JSON: {json_path} ({e})")
                except Exception as e:
                    print(f"❌ Failed to save JSON file {json_path}: {e}")
                    continue

            # Fill result columns from analysis (only requested markers)
            if "max" in markers and analysis.get("yield_stress"):
                df_index.at[idx, "Yield Stress (x)"] = analysis["yield_stress"].get("strain", pd.NA)
                df_index.at[idx, "Yield Stress (y)"] = analysis["yield_stress"].get("stress", pd.NA)
            if "inflection" in markers and analysis.get("inflection"):
                df_index.at[idx, "Inflection (x)"] = analysis["inflection"].get("strain", pd.NA)
                df_index.at[idx, "Inflection (y)"] = analysis["inflection"].get("stress", pd.NA)
            # [DISABLED] Strongest curvature fill removed as a strength definition — uncomment to re-enable.
            # if "curvature" in markers and analysis.get("strongest_curvature"):
            #     df_index.at[idx, "Strongest Curvature (x)"] = analysis["strongest_curvature"].get("strain", pd.NA)
            #     df_index.at[idx, "Strongest Curvature (y)"] = analysis["strongest_curvature"].get("stress", pd.NA)
            #     df_index.at[idx, "Curvature"] = analysis["strongest_curvature"].get("curvature", pd.NA)

        print(f"✅ Completed batch processing for {len(df_index)} file(s).")
        return df_index

    return cb.condense(_batch_inner)


def summarize_by_group_interactive(df_index, display_output=True):
    """
    Summarizes df_index by Specimen Group with mean and std (for each *Y* value column only).
    Interactive dropdown for individual group entries.
    Includes buttons to export the group-averaged summary or the selected group's DataFrame.
    """
    if df_index is None or df_index.empty or "Specimen Group" not in df_index.columns:
        print("❌ Invalid df_index: missing or empty.")
        if not display_output:
            return pd.DataFrame(), pd.DataFrame()
        return

    # --- Define relevant columns ---
    mean_cols = [
        "Yield Stress (x)", "Yield Stress (y)",
        "Inflection (x)", "Inflection (y)",
        # [DISABLED] Strongest curvature columns removed as strength definitions — uncomment to re-enable.
        # "Strongest Curvature (x)", "Strongest Curvature (y)",
        # "Curvature"
    ]
    # Only those that exist
    mean_cols = [col for col in mean_cols if col in df_index.columns]

    # --- Identify Y-value columns (stress) for std ---
    y_cols = [col for col in mean_cols if "(y)" in col.lower()]
    # If you want std for curvature, add it here:
    # y_cols.append("Curvature")  # only if you want

    # --- Numeric conversion ---
    df_index[mean_cols] = df_index[mean_cols].apply(pd.to_numeric, errors='coerce')

    # --- Means ---
    means = df_index.groupby("Specimen Group")[mean_cols].mean(numeric_only=True)
    # --- Stds for y columns only ---
    stds = df_index.groupby("Specimen Group")[y_cols].std(numeric_only=True)
    # Rename std columns
    stds = stds.rename(columns={c: f"{c} (std)" for c in y_cols})

    # --- Combine ---
    summary_df = pd.concat([means, stds], axis=1).reset_index()
    summary_df = summary_df.round(4)

    unique_groups = sorted(df_index["Specimen Group"].dropna().unique())

    if not display_output:
        if unique_groups:
            first_group = unique_groups[0]
            initial_group_df = df_index[df_index["Specimen Group"] == first_group].copy()
        else:
            initial_group_df = pd.DataFrame()
        return summary_df, initial_group_df

    print("📊 Group-Averaged Curve Analysis (Y-value std dev shown):")
    display(summary_df)

    if unique_groups:
        group_dropdown = widgets.Dropdown(
            options=unique_groups,
            description="Group:",
            layout=widgets.Layout(width='50%')
        )
        output_table = widgets.Output()

        export_summary_btn = widgets.Button(description="⬇️ Export Group-Averaged CSV", layout=widgets.Layout(width='auto'))
        export_group_btn = widgets.Button(description="⬇️ Export Selected Group CSV", layout=widgets.Layout(width='auto'))
        download_link = widgets.HTML("")

        def get_download_link(df, filename):
            csv_buffer = io.StringIO()
            df.to_csv(csv_buffer, index=False)
            b64 = base64.b64encode(csv_buffer.getvalue().encode()).decode()
            href = f'<a download="{filename}" href="data:text/csv;base64,{b64}">Click to download: {filename}</a>'
            return href

        def on_export_summary_clicked(_):
            download_link.value = get_download_link(summary_df, "group_averaged_curve_analysis.csv")

        def on_export_group_clicked(_):
            group = group_dropdown.value
            group_df = df_index[df_index["Specimen Group"] == group].copy()
            download_link.value = get_download_link(group_df, f"curve_analysis_{group}.csv")

        export_summary_btn.on_click(on_export_summary_clicked)
        export_group_btn.on_click(on_export_group_clicked)

        def show_group_table(change):
            output_table.clear_output()
            group = change["new"]
            with output_table:
                group_df = df_index[df_index["Specimen Group"] == group].copy()
                display(group_df)

        group_dropdown.observe(show_group_table, names="value")
        display(widgets.HBox([export_summary_btn, export_group_btn, download_link]))
        display(widgets.VBox([group_dropdown, output_table]))
        show_group_table({"new": group_dropdown.value})
    else:
        print("No specimen groups found in df_index.")


def plot_max_by_group(
    df,
    metric='Yield Stress (y)',
    group_col='Specimen Group',
    figsize=(20, 7)
):
    """
    Plots group means for a selected metric with error bar whiskers (mean ± std).
    Each group shows a single point/bar, not a full boxplot.
    """
    if metric not in df.columns:
        raise ValueError(f"❌ Metric '{metric}' not found in DataFrame columns.")

    # Calculate group means and stds
    group_stats = df.groupby(group_col)[metric].agg(['mean', 'std']).reset_index()
    groups = group_stats[group_col]
    means = group_stats['mean']
    stds = group_stats['std']

    plt.style.use('fivethirtyeight')
    fig, ax = plt.subplots(figsize=figsize)

    # Plot mean as point, std as whisker
    ax.errorbar(
        x=np.arange(len(groups)),
        y=means,
        yerr=stds,
        fmt='o', capsize=8, markersize=14, linewidth=2, ecolor='gray', color='tab:blue'
    )

    ax.set_xticks(np.arange(len(groups)))
    ax.set_xticklabels(groups, rotation=90)
    ax.set_ylabel(metric.replace("(y)", "").strip())
    ax.set_xlabel(group_col)
    ax.set_title(f"{metric.replace('(y)', '').strip()} by {group_col} (Mean ± Std)")
    plt.tight_layout()
    plt.show()


def max_json_safe(obj):
    import numpy as np
    import pandas as pd
    if isinstance(obj, dict):
        return {k: max_json_safe(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [max_json_safe(i) for i in obj]
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, pd.DataFrame):
        return obj.to_dict(orient="list")
    elif isinstance(obj, pd.Series):
        return obj.tolist()
    else:
        return obj
