from IPython.display import display, clear_output
import ipywidgets as widgets
import os
import sys
import io
import pandas as pd
import numpy as np
import matplotlib
from collections import Counter, defaultdict
import Plotting.Polyfit_Processor as pp
import Plotting.Max_Processor as mp
import Plotting.Single_Plot as sp
import Utility.csv_file_browser as cb
import re

def select_subfolder_and_plot_group(df_index, markers=None):
    """
    Interactive group plot for stress/strain curves.
    `markers` can be:
      - None (default): plot all markers
      - string: e.g. "inflection" (only plot inflection markers)
      - tuple/list of strings: e.g. ("inflection", "max")
    Allowed values: "inflection", "max"
    """
    grouped = _group_files_by_specimen(df_index)
    subfolder_dropdown = _make_group_dropdown(grouped)
    output = widgets.Output()

    def plot_selected_group(group_name):
        output.clear_output()
        with output:
            cb.condense(_plot_group_inner, group_name)

    def _plot_group_inner(group_name):
        clear_output(wait=True)
        results_list = _get_group_results(grouped[group_name], markers)
        if not results_list:
            print(f"❌ No valid files found in group: {group_name}")
            return
        if len(results_list) == 1:
            sp.plot_from_csv_results(results_list[0]['selected_df'])
        else:
            sp.plot_from_summary_row(results_list, markers=markers)

    def on_select(change):
        if change['type'] == 'change' and change['name'] == 'value':
            plot_selected_group(change['new'])
    subfolder_dropdown.observe(on_select)

    display(widgets.VBox([subfolder_dropdown, output]))
    plot_selected_group(subfolder_dropdown.value)

def _group_files_by_specimen(df_index):
    grouped = defaultdict(list)
    for _, row in df_index.iterrows():
        group = row["Specimen Group"]
        path = row["Full Path"]
        grouped[group].append(path)
    return grouped

def _make_group_dropdown(grouped):
    return widgets.Dropdown(
        options=sorted(grouped.keys()),
        description="Subfolder:",
        layout=widgets.Layout(width='100%')
    )

def _get_group_results(file_paths, markers=False):
    # Use cb.condense to batch-condense errors for all files in this group
    def _inner():
        results_list = []
        for path in file_paths:
            if not os.path.exists(path):
                print(f"⚠️ Skipping: Invalid file path: {path}")
                continue
            df = cb.load_and_process_csv(path)
            if df is None or df.empty:
                continue

            try:
                if "Stress Corrected" not in df.columns or "Strain Corrected" not in df.columns:
                    df = mp.correct_stress_and_strain(df, path=path)
            except Exception as e:
                print(f"❌ Could not correct {path}: {e}")
                continue

            if markers:
                df_fit = pp.find_and_fit(df, path, overwrite=False)
                mp.print_max_summary_df(df_fit)
                curve_analysis = df_fit.attrs.get('curve_analysis', {})
                df.attrs['curve_analysis'] = curve_analysis
            else:
                curve_analysis = df.attrs.get('curve_analysis', {})

            results_list.append({
                "selected_df": df,
                "selected_file_path": path,
                "curve_analysis": curve_analysis
            })
        return results_list
    return cb.condense(_inner)

def average_curve_for_subfolder(
    df_index,
    subfolder_col="Specimen Group",
    smoothing_window=None
):
    """
    Given a df_index that contains paths to processed curve CSVs and their group assignments (e.g., subfolder or batch),
    returns a dict of average stress-strain curves (and optionally std devs) for each unique subfolder.
    Each average is resampled/interpolated onto a common strain axis for fair averaging.
    Returns: dict {subfolder: DataFrame with columns: 'Strain', 'Stress Avg', 'Stress Std'}
    """
    result = {}
    for group, group_df in df_index.groupby(subfolder_col):
        curves = []
        for _, row in group_df.iterrows():
            path = row.get("Full Path", None)
            if not (isinstance(path, str) and os.path.isfile(path)):
                continue
            # Load and process CSV (always runs correction)
            df = cb.load_and_process_csv(path)
            # Find the first column matching 'Strain Corrected' (any units allowed)
            strain_col = next((col for col in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", col)), None)
            stress_col = next((col for col in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", col)), None)
            if not strain_col or not stress_col:
                continue
            strain = df[strain_col].values
            stress = df[stress_col].values
            if smoothing_window and len(stress) > smoothing_window:
                from scipy.signal import savgol_filter
                stress = savgol_filter(stress, smoothing_window, 2)
            curves.append((strain, stress))
        if not curves:
            continue
        # Interpolate all to common strain axis
        min_x = max([min(x) for x, _ in curves])
        max_x = min([max(x) for x, _ in curves])
        n_points = min([len(x) for x, _ in curves])
        if min_x >= max_x or n_points < 2:
            continue
        common_strain = np.linspace(min_x, max_x, n_points)
        stacked_stress = []
        for x, y in curves:
            y_interp = np.interp(common_strain, x, y)
            stacked_stress.append(y_interp)
        stacked_stress = np.array(stacked_stress)
        avg = stacked_stress.mean(axis=0)
        std = stacked_stress.std(axis=0)
        avg_df = pd.DataFrame({
            "Strain": common_strain,
            "Stress Avg": avg,
            "Stress Std": std
        })
        result[group] = avg_df
    return result

def interactive_average_curve_groups_only(
    df_index,
    group_col="Specimen Group",
    smoothing_window=None,
    markers=None
):
    """
    Interactive widget: Select groups, toggle which markers are visible, plot group average curves with markers.

    Average curves are computed once when the function is called; subsequent
    interactions (group selection, marker toggles) redraw instantly from the
    cached result.  Marker dots are coloured to match their source curve; a
    single black legend entry is shown per marker type to keep the legend compact.
    """
    # [DISABLED] "curvature" removed as a strength definition — add it back to re-enable.
    allowed_types = ["max", "inflection"]  # , "curvature"
    marker_y_cols = {
        "max": "Yield Stress (y)",
        "inflection": "Inflection (y)",
        # [DISABLED] "curvature": "Strongest Curvature (y)",  — removed as a strength definition
    }
    marker_x_cols = {
        "max": "Yield Stress (x)",
        "inflection": "Inflection (x)",
        # [DISABLED] "curvature": "Strongest Curvature (x)",  — removed as a strength definition
    }
    marker_legend_names = {
        "max": "Yield Stress",
        "inflection": "Inflection",
        # [DISABLED] "curvature": "Strongest Curvature",  — removed as a strength definition
    }

    def parse_initial_marker_state(markers):
        if markers is True or markers is None:
            return {k: True for k in allowed_types}
        if markers is False:
            return {k: False for k in allowed_types}
        if isinstance(markers, str):
            return {k: (k == markers) for k in allowed_types}
        if isinstance(markers, (set, list, tuple)):
            return {k: (k in markers) for k in allowed_types}
        return {k: True for k in allowed_types}

    marker_state = parse_initial_marker_state(markers)
    checkboxes = {}
    for k in allowed_types:
        cbx = widgets.Checkbox(value=marker_state[k], description=marker_legend_names[k], indent=False)
        checkboxes[k] = cbx
    marker_box = widgets.VBox([
        widgets.Label("Choose markers to display:"),
        *(checkboxes[k] for k in allowed_types)
    ], layout=widgets.Layout(min_width="160px", border="1px solid #ddd", padding="6px", align_items="flex-start"))

    def get_show_markers():
        return {k for k in allowed_types if checkboxes[k].value}

    # Compute average curves once upfront so redraws are instant
    avg_curve_dict = cb.condense(
        lambda: average_curve_for_subfolder(df_index, subfolder_col=group_col, smoothing_window=smoothing_window)
    )
    if not avg_curve_dict:
        print(f"❌ No valid average curves found for grouping by {group_col}.")
        return

    group_names = sorted(avg_curve_dict.keys())
    cmap = matplotlib.colormaps['tab10']
    # Map each group to a stable colour so markers and curves always match
    group_colors = {g: cmap(i % 10) for i, g in enumerate(group_names)}

    group_selector = widgets.SelectMultiple(
        options=group_names,
        value=tuple(group_names),
        description="Groups:",
        layout=widgets.Layout(width='60%', height='160px')
    )
    plot_out = widgets.Output()

    def draw_plot(*_):
        with plot_out:
            plot_out.clear_output(wait=True)
            data_series = []
            all_markers = []
            show_markers = get_show_markers()
            try:
                for group in group_selector.value:
                    avg_df = avg_curve_dict[group]
                    color = group_colors[group]
                    data_series.append({
                        'x': avg_df['Strain'],
                        'y': avg_df['Stress Avg'],
                        'std': avg_df['Stress Std'] if 'Stress Std' in avg_df else None,
                        'label': group,
                        'color': color
                    })
                    df_group = df_index[df_index[group_col] == group]
                    for mtype in allowed_types:
                        x_col = marker_x_cols[mtype]
                        y_col = marker_y_cols[mtype]
                        if (x_col in df_group.columns and y_col in df_group.columns
                                and not df_group[x_col].isna().all()
                                and not df_group[y_col].isna().all()):
                            all_markers.append({
                                'x': np.nanmean(df_group[x_col].values),
                                'y': np.nanmean(df_group[y_col].values),
                                'kind': mtype,
                                'color': color,  # matches its curve
                            })
                filtered_markers = [m for m in all_markers if m['kind'] in show_markers]
                sp.plot_fivethirtyeight_style(
                    data_series=data_series,
                    title=f"Average Curves by {group_col}",
                    x_label='Strain',
                    y_label='Stress',
                    markers=filtered_markers if show_markers else None
                )
            except Exception as e:
                print(f"Error during plotting: {e}")
                import traceback
                traceback.print_exc()

    group_selector.observe(lambda change: draw_plot(), names="value")
    for k in allowed_types:
        def handler(change, k=k):
            draw_plot()
        checkboxes[k].observe(handler, names="value")

    draw_plot()
    display(widgets.HBox([
        group_selector, marker_box
    ], layout=widgets.Layout(align_items="flex-start", margin="0 0 16px 0")))
    display(plot_out)


def select_subfolder_and_plot_group_moe(df_index, y_margin=1.25):
    """
    Interactive group plot for stress/strain curves with individual MOE fits.

    For each group (subfolder), overlays:
      - All sample stress-strain curves (corrected)
      - Each sample's MOE fit line (dashed red, labelled with MOE and R²)

    Uses a dropdown to select the group; the plot refreshes on change.
    """
    # Local import to avoid circular dependency (MOE_Processor imports Multi_Plot)
    import Plotting.MOE_Processor as moe
    import matplotlib.pyplot as plt
    from matplotlib import cm

    grouped = defaultdict(list)
    for _, row in df_index.iterrows():
        grouped[row["Specimen Group"]].append(row["Full Path"])

    subfolder_dropdown = _make_group_dropdown(grouped)
    output = widgets.Output()

    def plot_selected_group(group_name):
        output.clear_output(wait=True)
        with output:
            paths = grouped[group_name]
            cmap = cm.get_cmap('tab10')
            plt.figure(figsize=(10, 7))
            plotted_any = False
            _plot_max_y = 0.0

            for i, path in enumerate(paths):
                if not os.path.exists(path):
                    continue
                df = cb.load_and_process_csv(path)
                if df is None or df.empty:
                    continue

                stress_cols = [c for c in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", c)]
                strain_cols = [c for c in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", c)]
                if not stress_cols or not strain_cols:
                    df = mp.correct_stress_and_strain(df, path=path)
                    stress_cols = [c for c in df.columns if re.match(r"^Stress Corrected(\s*\([^)]+\))?$", c)]
                    strain_cols = [c for c in df.columns if re.match(r"^Strain Corrected(\s*\([^)]+\))?$", c)]
                    if not stress_cols or not strain_cols:
                        print(f"❌ Still missing corrected columns for {path}. Skipping.")
                        continue

                x_col, y_col = strain_cols[0], stress_cols[0]
                df[x_col] = pd.to_numeric(df[x_col], errors='coerce')
                df[y_col] = pd.to_numeric(df[y_col], errors='coerce')
                df_clean = df[[x_col, y_col]].dropna()
                if df_clean.empty:
                    continue

                label = os.path.basename(path)
                color = cmap(i % 10)
                plt.plot(df_clean[x_col], df_clean[y_col],
                         label=label, color=color, lw=1.5, alpha=0.6)
                _py = df_clean[y_col].values
                _fin = _py[np.isfinite(_py)]
                if len(_fin) > 0:
                    _plot_max_y = max(_plot_max_y, float(np.nanmax(_fin)))

                try:
                    result_fit = moe.fit_modulus_from_df(df_clean)
                    if result_fit:
                        def _sig(x, s=3):
                            return "0" if (x == 0 or pd.isnull(x)) else f"{x:.{s}g}"
                        bounds = ""
                        if 'fit_range' in result_fit:
                            bounds = f" [{result_fit['fit_range'][0]:.3f}\u2013{result_fit['fit_range'][1]:.3f}]"
                        plt.plot(result_fit['fit_x'], result_fit['fit_y'],
                                 '--', color='red', lw=2, alpha=0.7,
                                 label=f"{label} MOE={_sig(result_fit['modulus'])}, R\u00b2={_sig(result_fit['r2'])}{bounds}")
                        plotted_any = True
                except Exception as e:
                    print(f"MOE fit error for {label}: {e}")

            plt.xlabel('Strain (corrected)')
            plt.ylabel('Stress (corrected)')
            plt.title(f"Stress-Strain with Elastic Modulus Fits — {group_name}")
            plt.xlim(0, None)
            plt.ylim(0, _plot_max_y * y_margin if _plot_max_y > 0 else 1.0)
            if plotted_any:
                plt.legend(fontsize=9, loc='best')
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.show()

    def on_select(change):
        if change['type'] == 'change' and change['name'] == 'value':
            plot_selected_group(change['new'])
    subfolder_dropdown.observe(on_select)

    display(widgets.VBox([subfolder_dropdown, output]))
    plot_selected_group(subfolder_dropdown.value)


def plot_strength_moe_by_group(
    group_labels,
    strength_means, strength_stds,
    moe_means, moe_stds,
    show_strength=True, show_moe=True,
    colors=None,
    x_label="Group", y_label_left="Max Stress", y_label_right="Elastic Modulus",
    title="Strength and MOE by Group",
    legend_loc="upper left",
    fontsize=20,
    x_label_rotation=60,
    y_sigfigs=3,
    ylims_left=None,
    ylims_right=None,
    title_size=24,
    title_pad=10,
    x_label_size=20,
    x_label_pad=6,
    y_label_size=20,
    y_label_pad=6,
    save_path=None,
):
    """
    Error-bar plot of per-group strength and/or ductility means with ± std whiskers.

    Left axis = strength metric (circles), right axis = ductility metric (squares).
    Both axes share the same group positions; a small horizontal offset separates
    the two series when both are shown. Both y-axes start at 0 in auto mode.
    """
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter

    plt.style.use('fivethirtyeight')
    fig, ax = plt.subplots(figsize=(12, 9))
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')

    n = len(group_labels)
    x = np.arange(n)
    colors = colors or [f"C{i}" for i in range(n)]
    offset = 0.14
    ax2 = ax.twinx() if (show_strength and show_moe) else None

    if show_strength:
        x_s = x - (offset if show_moe else 0)
        for i in range(n):
            ax.errorbar(x_s[i], strength_means[i], yerr=strength_stds[i],
                        fmt='o', capsize=7, markersize=14,
                        color=colors[i], ecolor=colors[i], linewidth=2)

    if show_moe:
        x_m = x + (offset if show_strength else 0)
        y_ax = ax2 if ax2 else ax
        for i in range(n):
            y_ax.errorbar(x_m[i], moe_means[i], yerr=moe_stds[i],
                          fmt='s', capsize=7, markersize=14,
                          color=colors[i], ecolor=colors[i], linewidth=2)

    halign = 'center'
    if x_label_rotation > 0:
        halign = 'right'
    elif x_label_rotation < 0:
        halign = 'left'
    ax.set_xticks(x)
    ax.set_xticklabels(group_labels, rotation=x_label_rotation,
                       fontsize=fontsize, ha=halign, rotation_mode='anchor')
    ax.set_xlabel(x_label, fontsize=x_label_size, labelpad=x_label_pad)
    ax.set_title(title, fontsize=title_size, pad=title_pad)
    ax.tick_params(axis='y', labelsize=fontsize)
    if ax2:
        ax2.tick_params(axis='y', labelsize=fontsize)

    if ylims_left and len(ylims_left) == 2 and ylims_left[0] < ylims_left[1]:
        ymin, ymax = ylims_left
    else:
        ymin, ymax = 0, ax.get_ylim()[1]
    ax.set_yticks(np.linspace(ymin, ymax, 6))
    ax.set_ylim(ymin, ymax)

    if ax2:
        if ylims_right and len(ylims_right) == 2 and ylims_right[0] < ylims_right[1]:
            ymin2, ymax2 = ylims_right
        else:
            ymin2, ymax2 = 0, ax2.get_ylim()[1]
        ax2.set_yticks(np.linspace(ymin2, ymax2, 6))
        ax2.set_ylim(ymin2, ymax2)

    if y_sigfigs is not None:
        def _fmt_sig(v, pos=None, s=y_sigfigs):
            try:
                return "0" if v == 0 else f"{v:.{int(max(1, s))}g}"
            except Exception:
                return str(v)
        ax.yaxis.set_major_formatter(FuncFormatter(_fmt_sig))
        if ax2:
            ax2.yaxis.set_major_formatter(FuncFormatter(_fmt_sig))

    if show_strength:
        ax.set_ylabel(y_label_left, fontsize=y_label_size, labelpad=y_label_pad)
    if ax2 and show_moe:
        ax2.set_ylabel(y_label_right, fontsize=y_label_size, labelpad=y_label_pad)
    elif not show_strength:
        ax.set_ylabel(y_label_right, fontsize=y_label_size, labelpad=y_label_pad)

    plt.tight_layout()

    for spine in ['left', 'bottom', 'right', 'top']:
        ax.spines[spine].set_color('black')
        ax.spines[spine].set_linewidth(2.2)
        if ax2:
            ax2.spines[spine].set_color('black')
            ax2.spines[spine].set_linewidth(2.2)

    ax.grid(axis='y', which='major', linestyle='-', alpha=0.5)
    if ax2:
        ax2.grid(False)

    handles = []
    if show_strength:
        handles.append(plt.Line2D([], [], marker='o',
                                  color=colors[0] if colors else 'gray',
                                  markersize=12, linestyle='None', label=y_label_left))
    if show_moe:
        handles.append(plt.Line2D([], [], marker='s',
                                  color=colors[0] if colors else 'gray',
                                  markersize=12, linestyle='None', label=y_label_right))
    if handles:
        ax.legend(handles, [h.get_label() for h in handles],
                  loc=legend_loc, frameon=True, fontsize=fontsize)

    if save_path:
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        fig.savefig(save_path, format='svg', bbox_inches='tight')
        print(f"\u2705 Saved: {save_path}")
    plt.show()


def interactive_strength_moe_by_group(
    df_index_max,
    df_index_moe,
    group_col='Specimen Group',
    moe_col='Elastic Modulus',
    max_options=None,
    output_folder=None,
):
    """
    Interactive widget for comparing per-group strength and ductility as error-bar plots.

    Displays a dual-axis error-bar chart: left axis shows a user-selected strength
    metric (e.g. Yield Stress, Inflection Point); right axis shows Ductility (the
    strain at the selected metric).  Both y-axes start at 0 in auto mode.

    Controls provided:
    - **Metric dropdown**: selects the strength column; left-axis label and preset
      title update automatically when the selection changes.
    - **Show Title checkbox**: title is hidden by default; tick to reveal and edit.
    - **Title text box**: editable preset ``"<Metric> and Ductility by <group_col>
      (Mean ± Std)"``, updated dynamically when the metric changes.
    - **Left/Right Units boxes**: optional unit strings appended to y-axis labels
      in parentheses (e.g. ``"kPa"`` → ``"Yield Stress (kPa)"``).
    - **Show Ductility checkbox**: toggles the right-axis Ductility series.
    - Legend position, x-label rotation, font sizes, title size/pad, axis-limit
      overrides, group ordering/colouring, and SVG export.

    Calls `plot_strength_moe_by_group` internally.

    Parameters
    ----------
    df_index_max : pd.DataFrame
        Index table with per-specimen strength metrics and a ``group_col`` column.
    df_index_moe : pd.DataFrame
        Index table with per-specimen MOE/ductility columns and a ``group_col`` column.
    group_col : str
        Column name used to identify specimen groups (default ``'Specimen Group'``).
    moe_col : str
        Column name for elastic modulus values (default ``'Elastic Modulus'``).
    max_options : list of (label, col) tuples, optional
        Dropdown options mapping display labels to DataFrame column names.
        Defaults to Yield Stress and Inflection Point entries.
    output_folder : str or None
        Directory for SVG export.  If None the export button is disabled.
    """
    if max_options is None:
        max_options = [
            ('Yield Stress', 'Yield Stress (y)'),
            ('Inflection Point', 'Inflection (y)'),
        ]

    _initial_metric_label = max_options[0][0] if max_options else 'Metric'

    max_col_dropdown = widgets.Dropdown(
        options=max_options, value='Yield Stress (y)', description='Max Metric:')
    legend_positions = [
        ('Upper Left', 'upper left'), ('Upper Right', 'upper right'),
        ('Lower Left', 'lower left'), ('Lower Right', 'lower right'),
        ('Best', 'best'), ('Center Left', 'center left'),
        ('Center Right', 'center right'), ('Upper Center', 'upper center'),
        ('Lower Center', 'lower center'), ('Center', 'center'),
    ]
    legend_dropdown = widgets.Dropdown(
        options=legend_positions, value='upper left', description='Legend Pos:')
    xrot_slider    = widgets.IntSlider(value=60,  min=0,  max=90, step=5, description='X Label Angle:')
    ysig_slider    = widgets.IntSlider(value=3,   min=1,  max=6,  step=1, description='Y SigFigs:')
    fontsize_slider = widgets.IntSlider(value=20, min=10, max=36, step=1, description='Fontsize:')
    title_size_w   = widgets.IntSlider(value=24,  min=8,  max=64, step=1, description='Title Size:')
    title_pad_w    = widgets.IntSlider(value=10,  min=0,  max=60, step=1, description='Title Pad:')
    xlabel_size_w  = widgets.IntSlider(value=20,  min=8,  max=48, step=1, description='X Label Size:')
    xlabel_pad_w   = widgets.IntSlider(value=6,   min=0,  max=60, step=1, description='X Label Pad:')
    ylabel_size_w  = widgets.IntSlider(value=20,  min=8,  max=48, step=1, description='Y Label Size:')
    ylabel_pad_w   = widgets.IntSlider(value=6,   min=0,  max=60, step=1, description='Y Label Pad:')

    left_auto  = widgets.Checkbox(value=True, description='Left Y Auto')
    left_min   = widgets.FloatText(value=np.nan, description='Left Y min:')
    left_max   = widgets.FloatText(value=np.nan, description='Left Y max:')
    right_auto = widgets.Checkbox(value=True, description='Right Y Auto')
    right_min  = widgets.FloatText(value=np.nan, description='Right Y min:')
    right_max  = widgets.FloatText(value=np.nan, description='Right Y max:')

    preset_colors = ['#4c72b0','#dd8452','#55a868','#c44e52','#8172b3',
                     '#937860','#da8bc3','#8c8c8c','#ccb974','#64b5cd']
    group_names = sorted([g for g in set(df_index_max[group_col]) | set(df_index_moe[group_col])
                          if pd.notna(g)])
    group_state = {g: {'name': g, 'color': preset_colors[i % len(preset_colors)]}
                   for i, g in enumerate(group_names)}

    group_selector = widgets.SelectMultiple(
        options=group_names, value=tuple(group_names),
        description="Groups:", layout=widgets.Layout(width='60%', height='160px'))

    order_boxes = {}
    def make_order_boxes(selected):
        boxes = []
        for g in selected:
            if g not in order_boxes:
                order_boxes[g] = widgets.BoundedIntText(
                    value=selected.index(g)+1, min=1, max=len(selected), step=1,
                    layout=widgets.Layout(width='70px'))
            box = order_boxes[g]
            box.min = 1
            box.max = len(selected)
            box.value = min(max(int(box.value) if box.value is not None else 1, 1), len(selected))
            boxes.append(widgets.HBox([widgets.Label(g, layout=widgets.Layout(width='120px')), box]))
        return boxes

    orders_vbox = widgets.VBox(make_order_boxes(group_selector.value))

    def update_orders(change=None):
        selected = list(group_selector.value)
        for g in list(order_boxes.keys()):
            if g not in selected:
                del order_boxes[g]
        orders_vbox.children = tuple(make_order_boxes(selected))
        update_plot()

    group_selector.observe(update_orders, names='value')

    def make_controls(selected):
        controls = []
        for g in selected:
            txt = widgets.Text(value=group_state[g]['name'], layout=widgets.Layout(width='160px'))
            col = widgets.ColorPicker(value=group_state[g]['color'], layout=widgets.Layout(width='60px'))
            controls.append(widgets.HBox([
                widgets.Label(g, layout=widgets.Layout(width='120px')), txt, col]))
            def on_name(change, g=g): group_state[g]['name'] = change['new']; update_plot()
            def on_col(change, g=g):  group_state[g]['color'] = change['new']; update_plot()
            txt.observe(on_name, names='value')
            col.observe(on_col,  names='value')
        return controls

    controls_vbox = widgets.VBox(make_controls(group_selector.value))
    group_selector.observe(lambda c: setattr(controls_vbox, 'children',
                                             tuple(make_controls(group_selector.value))),
                           names='value')

    title_box      = widgets.Text(
                                  value=f"{_initial_metric_label} and Elastic Modulus by {group_col} (Mean \u00b1 Std)",
                                  description='Title:', layout=widgets.Layout(width='70%'))
    xaxis_box      = widgets.Text(value=group_col, description='X Axis:',
                                  layout=widgets.Layout(width='30%'))
    yaxis_left_box = widgets.Text(value=_initial_metric_label, description='Y Left:',
                                  layout=widgets.Layout(width='30%'))
    yaxis_right_box = widgets.Text(value='Elastic Modulus', description='Y Right:',
                                   layout=widgets.Layout(width='30%'))
    show_strength  = widgets.Checkbox(value=True, description='Show Max Metric')
    show_moe       = widgets.Checkbox(value=True, description='Show Ductility')
    show_title_w   = widgets.Checkbox(value=False, description='Show Title')
    yleft_units_w  = widgets.Text(value='MPa', description='Left Units:',
                                  layout=widgets.Layout(width='25%'))
    yright_units_w = widgets.Text(value='MPa', description='Right Units:',
                                  layout=widgets.Layout(width='25%'))
    output         = widgets.Output()
    current_save_path = [None]

    def _extract_ylims(auto_box, min_box, max_box):
        if auto_box.value:
            return None
        try:
            vmin, vmax = float(min_box.value), float(max_box.value)
            if np.isfinite(vmin) and np.isfinite(vmax) and vmin < vmax:
                return (vmin, vmax)
        except Exception:
            pass
        return None

    def _on_metric_change(change):
        for label, val in (max_col_dropdown.options or []):
            if val == change['new']:
                yaxis_left_box.value = label
                title_box.value = f"{label} and Elastic Modulus by {group_col} (Mean \u00b1 Std)"
                break
    max_col_dropdown.observe(_on_metric_change, names='value')

    def update_plot(*_):
        output.clear_output(wait=True)
        with output:
            strength_col = max_col_dropdown.value
            max_df = df_index_max[[group_col, strength_col]].copy()
            max_df[strength_col] = pd.to_numeric(max_df[strength_col], errors='coerce')
            max_df = max_df.dropna(subset=[group_col])
            moe_df = df_index_moe[[group_col, moe_col]].copy()
            moe_df[moe_col] = pd.to_numeric(moe_df[moe_col], errors='coerce')
            moe_df = moe_df.dropna(subset=[group_col])

            max_stats = max_df.groupby(group_col)[strength_col].agg(['mean','std']).reset_index()
            moe_stats = moe_df.groupby(group_col)[moe_col].agg(['mean','std']).reset_index()
            s_mean = dict(zip(max_stats[group_col], max_stats['mean']))
            s_std  = dict(zip(max_stats[group_col], max_stats['std']))
            m_mean = dict(zip(moe_stats[group_col], moe_stats['mean']))
            m_std  = dict(zip(moe_stats[group_col], moe_stats['std']))

            selected = list(group_selector.value)
            if not selected:
                print("\u26a0\ufe0f No groups selected.")
                return
            ordered = sorted(selected, key=lambda g: (order_boxes[g].value, g))

            _left_label  = yaxis_left_box.value + (f" ({yleft_units_w.value.strip()})" if yleft_units_w.value.strip() else "")
            _right_label = yaxis_right_box.value + (f" ({yright_units_w.value.strip()})" if yright_units_w.value.strip() else "")
            plot_strength_moe_by_group(
                [group_state[g]['name'] for g in ordered],
                np.array([s_mean.get(g, np.nan) for g in ordered]),
                np.array([s_std.get(g,  np.nan) for g in ordered]),
                np.array([m_mean.get(g, np.nan) for g in ordered]),
                np.array([m_std.get(g,  np.nan) for g in ordered]),
                show_strength.value, show_moe.value,
                [group_state[g]['color'] for g in ordered],
                x_label=xaxis_box.value,
                y_label_left=_left_label,
                y_label_right=_right_label,
                title=title_box.value if show_title_w.value else '',
                legend_loc=legend_dropdown.value,
                fontsize=fontsize_slider.value,
                x_label_rotation=xrot_slider.value,
                y_sigfigs=ysig_slider.value,
                ylims_left=_extract_ylims(left_auto, left_min, left_max),
                ylims_right=_extract_ylims(right_auto, right_min, right_max),
                title_size=title_size_w.value,   title_pad=title_pad_w.value,
                x_label_size=xlabel_size_w.value, x_label_pad=xlabel_pad_w.value,
                y_label_size=ylabel_size_w.value, y_label_pad=ylabel_pad_w.value,
                save_path=current_save_path[0],
            )
        current_save_path[0] = None

    for w in [title_box, xaxis_box, yaxis_left_box, yaxis_right_box,
              show_strength, show_moe, show_title_w, max_col_dropdown, legend_dropdown,
              fontsize_slider, xrot_slider, ysig_slider,
              left_auto, left_min, left_max, right_auto, right_min, right_max,
              title_size_w, title_pad_w, xlabel_size_w, xlabel_pad_w,
              ylabel_size_w, ylabel_pad_w, yleft_units_w, yright_units_w]:
        w.observe(update_plot, names='value')

    export_filename = widgets.Text(
        value='bulk_strength_moe.svg', description='Filename:',
        layout=widgets.Layout(width='40%'))
    export_btn = widgets.Button(
        description='Export SVG', button_style='success', icon='download',
        layout=widgets.Layout(width='140px'))
    export_status = widgets.Output()

    def on_export(_):
        export_status.clear_output(wait=True)
        with export_status:
            folder = output_folder if output_folder else os.path.join(os.getcwd(), 'output')
            fname = export_filename.value.strip() or 'bulk_strength_moe.svg'
            if not fname.lower().endswith('.svg'):
                fname += '.svg'
            current_save_path[0] = os.path.join(folder, fname)
            update_plot()

    export_btn.on_click(on_export)

    def _link_order_boxes():
        for box in order_boxes.values():
            box.observe(update_plot, names='value')
    group_selector.observe(lambda _: _link_order_boxes(), names='value')
    _link_order_boxes()

    order_panel  = widgets.VBox([widgets.HTML('<b>Set Position (left=1, right=N):</b>'), orders_vbox])
    config_panel = widgets.VBox([
        max_col_dropdown,
        widgets.HBox([legend_dropdown, fontsize_slider, xrot_slider, ysig_slider]),
        widgets.HTML('<b>Title &amp; Label Sizes / Spacing:</b>'),
        widgets.HBox([title_size_w, title_pad_w]),
        widgets.HBox([xlabel_size_w, xlabel_pad_w]),
        widgets.HBox([ylabel_size_w, ylabel_pad_w]),
        widgets.HTML('<b>Y-Limits:</b>'),
        widgets.HBox([left_auto, left_min, left_max]),
        widgets.HBox([right_auto, right_min, right_max]),
        widgets.HBox([show_title_w, title_box]),
        widgets.HBox([xaxis_box, yaxis_left_box, yaxis_right_box]),
        widgets.HBox([yleft_units_w, yright_units_w]),
        widgets.HBox([show_strength, show_moe]),
        widgets.HBox([group_selector, order_panel, controls_vbox]),
        widgets.HTML('<b>Export:</b>'),
        widgets.HBox([export_filename, export_btn, export_status]),
    ])
    display(config_panel)
    display(output)
    update_plot()
