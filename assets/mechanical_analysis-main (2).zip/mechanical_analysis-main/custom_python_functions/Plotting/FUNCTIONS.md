# Plotting — Function Reference

This package contains all functions for processing compression stress-strain curves
and generating publication-quality figures. Four modules work together as a pipeline:

```
csv_file_browser (Utility) → Polyfit_Processor → Max_Processor / MOE_Processor → Single_Plot / Multi_Plot
```

---

## Single_Plot.py

Interactive and batch plotting for individual specimen curves.

---

### `get_file_path_from_summary_row(summary_row)`

Extracts a valid file path from a summary DataFrame row.
Checks the keys `'Full Path'`, `'File Path'`, and `'selected_file_path'` in order and
returns the first one that resolves to an existing file, or `None`.

---

### `plot_from_csv_results(df_or_dict)`

Plots a stress-strain curve from a processed DataFrame or a dict containing
`'selected_df'`. Auto-detects `Stress Corrected` and `Strain Corrected` columns
(with or without units). Calls `correct_stress_and_strain` if the corrected columns
are missing, then delegates to `plot_fivethirtyeight_style`.

**Parameters**
- `df_or_dict` — `pd.DataFrame` or `dict` with a `'selected_df'` key

---

### `plot_from_summary_row(input_obj, markers=None)`

Plots one or more stress-strain curves from a DataFrame, dict, or list of dicts.
Overlays yield stress and inflection point markers read from `df.attrs['curve_analysis']`.

**Parameters**
- `input_obj` — `pd.DataFrame`, `dict`, or `list` of dicts
- `markers` — which marker types to show:
  - `None` or `True` — all markers (`"max"`, `"inflection"`)
  - `False` — no markers
  - `str` — single type, e.g. `"inflection"`
  - `list/tuple` — subset, e.g. `["max", "inflection"]`

Calls `plot_fivethirtyeight_style` after collecting all series and marker coordinates.

---

### `plot_fivethirtyeight_style(x, y, data_series, x_label, y_label, title, figsize, markers)`

Core rendering function. Draws stress-strain curve(s) in a clean white figure with
interactive X/Y range sliders (via `add_slider_widget`).

**Parameters**
- `x`, `y` — single curve arrays (mutually exclusive with `data_series`)
- `data_series` — list of `{'x', 'y', 'label'}` dicts for multi-curve plots
- `x_label`, `y_label`, `title` — axis and figure labels
- `figsize` — matplotlib figure size tuple (default `(12, 8)`)
- `markers` — list of `{'x', 'y', 'kind', 'label', 'color'}` dicts

Marker styles: yield stress = red `X`, inflection = orange `o`.
Displays the plot inside a `widgets.VBox` with X and Y range sliders.

---

### `export_all_strength_svg(target_folder, output_folder, markers, xlim, ylim)`

Processes every CSV in `target_folder` and saves **one SVG per specimen** to
`output_folder`. Each file is named after the specimen (e.g. `specimen_01.svg`).
Uses `build_df_index` + `load_and_process_csv` + `find_and_fit` + `print_max_summary_df`
internally. Shows an `IntProgress` bar during export.

**Parameters**
- `target_folder` — folder to search recursively for CSVs
- `output_folder` — destination folder for the SVGs (default: `./output/` relative to cwd)
- `markers` — same filtering syntax as `plot_from_summary_row`
- `xlim` — `(min, max)` strain axis limits applied to every SVG; `None` = matplotlib auto-scale
- `ylim` — `(min, max)` stress axis limits applied to every SVG; `None` = matplotlib auto-scale

**Returns** list of saved SVG paths.

---

### `export_groups_strength_svg(target_folder, output_folder, markers)`

Processes every CSV in `target_folder` and saves **one SVG per specimen group** to
`output_folder`. Each file is named after the specimen group (e.g. `Group_A.svg`).
All specimens within a group are overlaid on a single figure using `tab10` colours,
with yield stress and inflection point markers drawn per specimen.

Shows an `IntProgress` bar counting groups (not individual specimens) during export.

**Parameters**
- `target_folder` — folder to search recursively for CSVs
- `output_folder` — destination folder for the SVGs (default: `./output/` relative to cwd)
- `markers` — same filtering syntax as `plot_from_summary_row`

**Returns** list of saved SVG paths.

---

### `choose_and_plot_summary(summary_df)`

Displays a dropdown widget populated from `summary_df['File Name']`.
On selection, calls `plot_from_summary_row` for the chosen row.

---

## Multi_Plot.py

Group-level interactive plots. Groups specimens by the subfolder they live in
(the `Specimen Group` column of `df_index`).

---

### `select_subfolder_and_plot_group(df_index, markers=None)`

Interactive dropdown that lets the user pick a specimen group, then plots all
curves in that group overlaid in a single figure. If the group has only one file,
falls back to `plot_from_csv_results`.

**Parameters**
- `df_index` — DataFrame index built by `build_df_index`
- `markers` — same filtering syntax as `plot_from_summary_row`

**Internal helpers:**
- `_group_files_by_specimen(df_index)` — builds a `{group_name: [paths]}` dict
- `_make_group_dropdown(grouped)` — creates the ipywidgets Dropdown
- `_get_group_results(file_paths, markers)` — loads, corrects, and optionally fits
  all CSVs in a group; returns a list of result dicts

---

### `average_curve_for_subfolder(df_index, subfolder_col, smoothing_window)`

Computes a group-averaged stress-strain curve for each unique value of `subfolder_col`.
All individual curves are interpolated onto a common strain axis before averaging,
so groups with different sampling densities are handled correctly.

**Parameters**
- `df_index` — DataFrame index with `Specimen Group` and `Full Path` columns
- `subfolder_col` — column to group by (default: `"Specimen Group"`)
- `smoothing_window` — optional Savitzky-Golay window length applied to each curve
  before averaging; requires `scipy.signal.savgol_filter`

**Returns** `dict { group_name: DataFrame }` where each DataFrame has columns
`'Strain'`, `'Stress Avg'`, `'Stress Std'`.

---

### `interactive_average_curve_groups_only(df_index, group_col, smoothing_window, markers)`

Full interactive widget for group-averaged curves. Displays:
- A `SelectMultiple` widget to choose which groups to show
- A checkbox panel to toggle marker types (yield stress, inflection)
- The average curve plot with ±std shading and mean markers

**Parameters**
- `df_index` — DataFrame index
- `group_col` — grouping column (default: `"Specimen Group"`)
- `smoothing_window` — passed through to `average_curve_for_subfolder`
- `markers` — initial marker visibility (`None`/`True` = all on)

---

## Max_Processor.py

Extracts strength-related feature points from a fitted stress-strain curve.
All feature extraction operates on polynomial fit output stored in `df.attrs`.

---

### `correct_stress_and_strain(df, path=None, overwrite=True)`

Adds zero-corrected `Stress Corrected` and `Strain Corrected` columns.

**Stress correction:** subtracts the first stress reading so the curve starts at zero.

**Strain correction:** finds the strain index where corrected stress first enters
`[0.001, 0.01]` (the seating region), then shifts strain so that point is the
new zero. Falls back to the nearest-value approach if no points fall in range.

Preserves any unit suffix found in parentheses in the original column name (e.g.,
`Stress Corrected (MPa)`). Optionally writes the updated DataFrame back to `path`.

**Parameters**
- `df` — input DataFrame
- `path` — CSV file path; if provided the updated DataFrame is written back
- `overwrite` — if `False`, skips re-correction when corrected columns already exist

---

### `record_minima_and_zeros(df)`

Computes the third derivative of the second-derivative fit column to find local
minima and zero-crossings. Stores two DataFrames in `df.attrs['curve_analysis']`:
- `'second_derivative_minima'` — strain/d2 values at local minima
- `'second_derivative_zeros'` — strain/d2 values at zero-crossings

Requires `df.attrs['strain_col']`, `df.attrs['x_plot']` (or `'x'`), and a
`"Second Derivative"` column to be present.

---

### `label_zero_crossing_directions(df)`

Labels each zero-crossing in the second derivative as `'Neg-to-Pos'`,
`'Pos-to-Neg'`, or `'Flat'`. Stores results in
`df.attrs['curve_analysis']['zero_directions']` as a DataFrame.

---

### `find_inflection_neg_to_pos(df)`

Finds all neg-to-pos zero-crossings of the second derivative (inflection points
where the curve transitions from concave-down to concave-up). Uses linear
interpolation for sub-sample precision.

From all candidates with `strain <= 60`, selects the one with the **highest
fitted stress** (tie-broken by highest strain). Stores the full candidate list
in `df.attrs['curve_analysis']['inflections_all']`.

**Returns** `{'strain': float, 'stress': float}` or `None`.

---

### `find_yield_stress_point(df)`

Finds the yield stress as the **highest-stress local maximum** of the polynomial
fit within the fit region (`df.attrs['fit_region_min']` to `'fit_region_max'`,
defaulting to 0–50% strain). `fit_region_min` is clamped to 0 so yield stress
is only ever returned at positive strains. Uses numerical gradient zero-crossings
of the first derivative.

**Returns** `{'strain': float, 'stress': float}` or `None`.

---

### `find_yield_stress_point_polyfit(df)`

Analytically finds the yield stress maximum using the polynomial coefficients
stored in `df.attrs['best_coeffs']`. Computes the derivative analytically via
`np.polyder`, finds all real roots within the fit region, and returns the root
with the highest stress. `fit_region_min` is clamped to 0 so yield stress is
only ever returned at positive strains. More numerically stable than
`find_yield_stress_point` for smooth polynomial fits.

**Returns** `{'strain': float, 'stress': float}` or `None`.

---

### `find_strongest_negative_curvature(df)` *(currently disabled)*

Finds the local minimum of the second derivative with the **highest strain** in
`0 <= strain <= 50`. Returns `{'strain', 'stress', 'curvature'}` or `None`.
This definition was explored as an alternative strength criterion but is currently
commented out in the analysis pipeline.

---

### `print_max_summary_df(df)`

Orchestrates feature extraction: calls `record_minima_and_zeros`,
`find_yield_stress_point_polyfit`, and `find_inflection_neg_to_pos`, then
stores all results in `df.attrs['curve_analysis']` and returns a one-row
summary DataFrame with columns:
- `'Yield Stress (x)'`, `'Yield Stress (y)'`
- `'Inflection (x)'`, `'Inflection (y)'`

---

### `batch_process_folder(target_folder, markers, overwrite_cache)`

Processes every CSV in `target_folder` recursively. For each file:
1. Checks for a sidecar `.curve_analysis.json` cache
2. If valid and `overwrite_cache=False`, reads from cache
3. Otherwise runs `find_and_fit` → `print_max_summary_df` and writes a new cache
4. Populates a `df_index` with all extracted feature columns

**Parameters**
- `target_folder` — root folder to search
- `markers` — set of marker types to extract (default: `{"max", "inflection"}`)
- `overwrite_cache` — force recalculation even if cache exists (default: `True`)

**Returns** populated `df_index` DataFrame.

---

### `summarize_by_group_interactive(df_index, display_output)`

Groups `df_index` by `Specimen Group`, computes mean ± std for all feature columns,
and displays the result. Provides:
- An interactive dropdown to browse per-group raw entries
- Export buttons for the group-averaged summary CSV and the selected group CSV

**Returns** `(summary_df, initial_group_df)` when `display_output=False`.

---

### `plot_max_by_group(df, metric, group_col, figsize)`

Plots group means for a single metric as points with ± std error bars.
Uses `fivethirtyeight` style.

**Parameters**
- `df` — `df_index` with group and metric columns
- `metric` — column to plot (default: `'Yield Stress (y)'`)
- `group_col` — grouping column (default: `'Specimen Group'`)

---

### `max_json_safe(obj)`

Recursively converts numpy arrays, DataFrames, and Series to JSON-serializable
Python types. Used before writing `.curve_analysis.json` cache files.

---

## MOE_Processor.py

Fits linear elastic modulus regions to stress-strain curves.

---

### `plot_moe_from_df(input_obj, fit_range, scan_min, scan_max, best_window, show_fit, xlim, ylim)`

Plots stress-strain curves with an overlaid elastic modulus (MOE) fit line.
Accepts a single DataFrame, dict, or list of dicts.

The fit line is drawn as a dashed red line labelled with MOE value (3 sig figs),
R², and the strain window used for the fit.

**Parameters**
- `fit_range` — width of the linear fit window in strain units
- `scan_min`, `scan_max` — search bounds for best-window scan
- `best_window` — if `True`, scans all windows of size `fit_range` to find the
  highest R² (recommended); if `False`, always fits `[0, fit_range]`
- `show_fit` — whether to overlay the fit line
- `xlim`, `ylim` — axis limits (defaults `(0, 15)`, `(0, 1)`)

---

### `correct_stress_and_strain(df, path, overwrite)`

Duplicate of the same function in `Max_Processor.py`. Included here so
`MOE_Processor` can operate independently without a circular import.
See `Max_Processor.correct_stress_and_strain` for full documentation.

---

### `fit_modulus_from_df(df, fit_range, scan_min, scan_max, best_window)`

Core MOE fitting function. Runs a linear regression over the specified strain window.

**Best-window mode (`best_window=True`):** scans windows of width `fit_range` starting
every `fit_range / 25` strain units from `scan_min` to `scan_max`. Returns the window
with the highest R².

**Classic mode (`best_window=False`):** fits the single window `[0, fit_range]`
(default `fit_range = 5`).

**Returns** a dict:
```python
{
    'modulus':    float,   # slope of the linear fit (elastic modulus)
    'intercept':  float,
    'r2':         float,
    'fit_x':      np.ndarray,
    'fit_y':      np.ndarray,
    'fit_range':  (start, end)
}
```
or `None` if insufficient data.

---

### `print_modulus_summary_df(df, fit_range, scan_min, scan_max, best_window)`

Calls `fit_modulus_from_df` and stores the result in `df.attrs['modulus_analysis']`.
Returns a one-row summary DataFrame with columns `'Elastic Modulus'` and
`'Modulus (fit R²)'`.

---

### `moe_numpy_to_list(obj)`

Recursively converts numpy arrays to Python lists for JSON serialization.
Used before writing `.modulus.json` cache files.

---

### `batch_process_folder(target_folder, fit_range, scan_min, scan_max, best_window, overwrite_cache)`

Processes every CSV in `target_folder` recursively, extracting elastic modulus for each.
Uses sidecar `.modulus.json` cache files; reads from cache when available unless
`overwrite_cache=True`.

**Returns** `df_index` with `'Elastic Modulus'` and `'Modulus (fit R²)'` columns filled.

---

### `summarize_by_group_interactive(df_index, display_output)`

Groups `df_index` by `Specimen Group`, shows mean elastic modulus ± std, and provides
an interactive dropdown to browse individual group entries. Export buttons generate
in-browser CSV download links.

**Returns** `(summary_df, initial_group_df)` when `display_output=False`.

---

### `export_all_moe_svg(target_folder, output_folder, fit_range, scan_min, scan_max, best_window, show_fit, xlim, ylim)`

Processes every CSV in `target_folder` and saves **one SVG per specimen** to
`output_folder`. Each file is named after the specimen (e.g. `specimen_01.svg`)
and shows that specimen's stress-strain curve with its individual MOE fit line
(dashed red, labelled with MOE value and R²). Shows an `IntProgress` bar during export.

**Parameters** mirror `plot_moe_from_df` plus:
- `output_folder` — destination folder for the SVGs (default: `./output/` relative to cwd)

**Returns** the saved SVG path.

---

### `export_groups_moe_svg(target_folder, output_folder, fit_range, scan_min, scan_max, best_window, show_fit, xlim, ylim)`

Processes every CSV in `target_folder` and saves **one SVG per specimen group** to
`output_folder`. Each file is named after the specimen group (e.g. `Group_A.svg`).
All specimens within a group are overlaid on a single figure using `tab10` colours,
with each specimen's individual MOE fit line drawn as a dashed line in the same colour.

Shows an `IntProgress` bar counting groups (not individual specimens) during export.

**Parameters** mirror `export_all_moe_svg` — same `fit_range`, `scan_min`, `scan_max`,
`best_window`, `show_fit`, `xlim`, `ylim` options — plus:
- `output_folder` — destination folder for the SVGs (default: `./output/` relative to cwd)

**Returns** list of saved SVG paths.

---

### `plot_elastic_modulus_by_group(df, group_col, value_col)`

Boxplot of elastic modulus values grouped by specimen group.
Uses `fivethirtyeight` style; one box per group.

---

## Polyfit_Processor.py

Polynomial curve fitting and derivative calculation. Acts as the first processing
step after stress/strain correction — its output is consumed by `Max_Processor`
and `MOE_Processor`.

---

### `r_squared(y_true, y_pred)`

Computes R² (coefficient of determination), ignoring `NaN` and `Inf` values.

---

### `adjusted_r_squared(r2, n, k)`

Computes adjusted R² penalizing for number of model parameters `k` and sample size `n`.

---

### `format_poly_equation(coeffs)`

Formats polynomial coefficients as a readable equation string:
`"f(x) = ax^n + bx^(n-1) + ... + z"`.

---

### `safe_gradient(y, x)`

Wrapper around `np.gradient(y, x)` that suppresses divide-by-zero and invalid
floating-point warnings.

---

### `find_and_fit(df, path=None, overwrite=True)`

Main fitting function. Fits polynomial degrees 3–9 to the corrected stress-strain curve:
- **Degrees 3–8:** fit only the region `0 <= strain <= 50%`
- **Degree 9:** fit over the full available data range

Always uses **Degree 9** as the canonical fit for downstream analysis (first and
second derivatives, yield stress extraction). Degrees 3–8 are retained for
comparison in `plot_polynomial_fits`.

Adds three new columns to the returned DataFrame:
- `"Polynomial Fit"` — Degree 9 fit evaluated over all x
- `"First Derivative (Fit)"` — numerical gradient of the fit
- `"Second Derivative (Fit)"` — numerical gradient of the first derivative

Stores rich metadata in `df.attrs`:
- `'best_coeffs'` — Degree 9 polynomial coefficients (list)
- `'best_label'` — `"Degree 9"`
- `'equation_str'` — human-readable equation
- `'r_squared_dict'`, `'adj_r_squared_dict'` — per-degree quality metrics
- `'fit_region_min'`, `'fit_region_max'` — actual x bounds used for fitting
- `'x_plot'`, `'y_plot'` — raw x/y arrays for plotting
- `'y_smooth'` — Savitzky-Golay smoothed stress (window 51, order 3)

**Parameters**
- `df` — input DataFrame (must have corrected stress/strain columns)
- `path` — if provided, writes the updated DataFrame back to the CSV
- `overwrite` — if `True`, replaces existing fit/derivative columns (default: `True`)

**Returns** the updated DataFrame, or an empty DataFrame on failure.

---

### `summarize_polynomial_fit(result_df)`

Prints a text summary of the best fit: degree, R², adjusted R², and equation string.
Reads from `result_df.attrs`.

---

### `plot_polynomial_fits(df_result, csv_results=None)`

Interactive Plotly visualisation of all polynomial fit degrees overlaid on the raw
curve. Generates three separate figures:
1. All fits (Degree 3–9) vs raw stress — zoomable, default view 0–70% strain
2. First derivative of the Degree 9 fit
3. Second derivative of the Degree 9 fit with zero-crossings and minima annotated
