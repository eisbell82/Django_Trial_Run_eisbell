import os

# Derived from this file's location: custom_python_functions/Utility/ -> custom_python_functions/
base_dir = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
for root, dirs, files in os.walk(base_dir):
    for d in dirs:
        init_path = os.path.join(root, d, '__init__.py')
        if not os.path.exists(init_path):
            open(init_path, 'w').close()
