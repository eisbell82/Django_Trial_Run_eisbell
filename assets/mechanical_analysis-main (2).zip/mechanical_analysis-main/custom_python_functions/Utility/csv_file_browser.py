import os
import sys

# Paths derived from this file's location inside the repository
_UTILITY_DIR = os.path.dirname(os.path.abspath(__file__))        # custom_python_functions/Utility/
_CUSTOM_PY_ROOT = os.path.abspath(os.path.join(_UTILITY_DIR, '..'))  # custom_python_functions/
_REPO_ROOT = os.path.abspath(os.path.join(_UTILITY_DIR, '..', '..'))  # repository root
import time
import importlib
import importlib.util
import importlib.machinery
import shutil
import pandas as pd
from IPython.display import display, HTML
import ipywidgets as widgets
import Plotting.Polyfit_Processor as pp
import Plotting.Max_Processor as mp
import Plotting.Single_Plot as sp
import Plotting.Multi_Plot as mult
import re
import io
from collections import Counter

# Global store for file modification times
_last_modified_times = {}

# Session-level in-memory cache: avoids repeated Drive I/O within a single session.
# Maps file_path -> (csv_mtime, df_snapshot).  A fresh copy is returned on each hit
# so callers can mutate freely without corrupting the cache.
_df_session_cache = {}

def list_csv_files(target_folder):
    csv_files = []
    for root, dirs, files in os.walk(target_folder):
        for file in files:
            if file.lower().endswith(".csv") and not file.startswith("._"):
                full_path = os.path.join(root, file)
                csv_files.append(full_path)

    csv_files.sort()

    data = []
    for f in csv_files:
        file_name = os.path.basename(f)
        specimen_id = os.path.splitext(file_name)[0]
        specimen_group = os.path.basename(os.path.dirname(f))
        data.append({
            "File Name": file_name,
            "Full Path": f,
            "Specimen ID": specimen_id,
            "Specimen Group": specimen_group
        })

    df_index = pd.DataFrame(data)
    print(f"✅ Found {len(csv_files)} CSV file(s) in: {target_folder}")
    return df_index

def build_df_index(folder):
    """
    Given a folder path, recursively finds all CSVs and builds a DataFrame index
    with File Name, Full Path, Specimen ID, and Specimen Group.
    """
    data = []
    for root, dirs, files in os.walk(folder):
        for file in files:
            if file.lower().endswith(".csv") and not file.startswith("._"):
                full_path = os.path.join(root, file)
                file_name = os.path.basename(full_path)
                specimen_id = os.path.splitext(file_name)[0]
                specimen_group = os.path.basename(os.path.dirname(full_path))
                data.append({
                    "File Name": file_name,
                    "Full Path": full_path,
                    "Specimen ID": specimen_id,
                    "Specimen Group": specimen_group
                })
    if not data:
        print("⚠️ No CSV files found.")
        return None
    df_index = pd.DataFrame(data)
    return df_index

def load_and_process_csv(file_path):
    """
    Loads a CSV, skipping bad lines and detecting/skipping unit/comment rows at the top.
    Uses a .parquet sidecar for fast re-loading of large files when available and up to date.
    Returns a cleaned DataFrame or None on error.
    """
    import pandas as pd
    import os
    import re

    def is_unit_string(s):
        if not isinstance(s, str):
            return False
        s = s.strip()
        unit_pattern = r"^[\[\(]?\s*([a-zA-Z%°μΩ/0-9\.\-\s]+)[\]\)]?$"
        if s.lower() in ["", "none", "nan"]:
            return False
        if re.match(r'^-?\d+(\.\d+)?$', s):  # Is a number
            return False
        return bool(re.match(unit_pattern, s))

    if not os.path.exists(file_path):
        print(f"❌ File does not exist: {file_path}")
        return None

    # --- Session cache: fastest path — no Drive I/O after first load ---
    try:
        current_mtime = os.path.getmtime(file_path)
        cached = _df_session_cache.get(file_path)
        if cached is not None and cached[0] == current_mtime:
            result = cached[1].copy()
            result.attrs['file_path'] = file_path
            return result
    except Exception:
        pass

    # --- Parquet sidecar: fast reload for large CSVs ---
    parquet_path = file_path + '.parquet'
    if os.path.exists(parquet_path):
        try:
            if os.path.getmtime(parquet_path) >= os.path.getmtime(file_path):
                df = pd.read_parquet(parquet_path)
                df.attrs['file_path'] = file_path
                try:
                    _df_session_cache[file_path] = (os.path.getmtime(file_path), df.copy())
                except Exception:
                    pass
                return df
        except Exception:
            pass  # Fall through to full CSV load

    try:
        # Try loading, skipping malformed lines
        df = pd.read_csv(file_path, header=0, dtype=str, on_bad_lines='skip')
    except Exception as e:
        print(f"❌ Failed to load {file_path}: {e}")
        return None

    # --- Detect and skip a unit row at the top (if present) ---
    if df.shape[0] > 0:
        row1 = df.iloc[0]
        unit_like = sum(is_unit_string(x) for x in row1)
        # If more than half of the entries look like units, skip this row
        if unit_like > (len(df.columns) // 2):
            new_columns = []
            for i, col in enumerate(df.columns):
                unit = str(row1.iloc[i]).strip()
                if is_unit_string(unit):
                    new_columns.append(f"{col} {unit}")
                else:
                    new_columns.append(col)
            df.columns = new_columns
            df = df.drop(df.index[0]).reset_index(drop=True)

    # --- Try converting numeric columns ---
    for col in df.columns:
        try:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        except Exception:
            pass

    # --- Optionally: add corrected stress/strain columns ---
    try:
        df = mp.correct_stress_and_strain(df, path=file_path)
    except Exception as e:
        print(f"⚠️ Correction failed: {e}")

    # --- Set file_path as attribute for plotting/labeling ---
    df.attrs['file_path'] = file_path

    # --- Save Parquet sidecar for fast future loads ---
    try:
        df.to_parquet(parquet_path, index=False)
    except Exception:
        pass

    # --- Update session cache ---
    try:
        _df_session_cache[file_path] = (os.path.getmtime(file_path), df.copy())
    except Exception:
        pass

    return df

def browse_csv_files_interactive(default_path=os.path.join(_REPO_ROOT, "input_data")):
    """
    Interactive CSV file browser for Jupyter. 
    After selecting a file, sets these attributes:
      - browse_csv_files_interactive.df_index
      - browse_csv_files_interactive.selected_file_path
      - browse_csv_files_interactive.selected_df
    """
    folder_input = widgets.Text(
        value=default_path,
        placeholder='Enter target folder path',
        description='Folder:',
        layout=widgets.Layout(width='100%')
    )
    run_button = widgets.Button(description="📂 Scan for CSVs")
    scan_output = widgets.Output()
    file_dropdown_output = widgets.Output()
    preview_output = widgets.Output()

    shared_state = {
        "df_index": None,
        "selected_file_path": None,
        "selected_df": None
    }

    def run_scan(_):
        scan_output.clear_output()
        file_dropdown_output.clear_output()
        preview_output.clear_output()
        with scan_output:
            folder = folder_input.value.strip()
            if not os.path.exists(folder):
                print(f"❌ Folder does not exist: {folder}")
                browse_csv_files_interactive.df_index = None
                return
            df_index = build_df_index(folder)
            if df_index is None:
                shared_state["df_index"] = None
                browse_csv_files_interactive.df_index = None
                return
            shared_state["df_index"] = df_index
            browse_csv_files_interactive.df_index = df_index
            display(df_index)

            with file_dropdown_output:
                dropdown = widgets.Dropdown(
                    options=[(row["File Name"], row["Full Path"]) for _, row in df_index.iterrows()],
                    description='Select CSV:',
                    layout=widgets.Layout(width='100%')
                )
                preview_button = widgets.Button(description="🔄 Show Selected CSV Head")
                display(widgets.HBox([dropdown, preview_button]))

                def on_select(change):
                    if change['type'] == 'change' and change['name'] == 'value':
                        shared_state["selected_file_path"] = change['new']

                dropdown.observe(on_select)
                shared_state["selected_file_path"] = dropdown.value

                def show_preview(_):
                    preview_output.clear_output()
                    file_path = shared_state.get("selected_file_path")
                    if not file_path:
                        with preview_output:
                            print("⚠️ No CSV selected yet.")
                        shared_state["selected_df"] = None
                        browse_csv_files_interactive.selected_df = None
                        browse_csv_files_interactive.selected_file_path = None
                        return
                    df = load_and_process_csv(file_path)
                    if df is not None:
                        shared_state["selected_df"] = df
                        browse_csv_files_interactive.selected_df = df
                        browse_csv_files_interactive.selected_file_path = file_path
                        with preview_output:
                            print(f"📊 Displaying: {os.path.basename(file_path)}")
                            display(df.head())
                    else:
                        with preview_output:
                            print(f"❌ Failed to load: {file_path}")
                        shared_state["selected_df"] = None
                        browse_csv_files_interactive.selected_df = None
                        browse_csv_files_interactive.selected_file_path = None

                preview_button.on_click(show_preview)

    run_button.on_click(run_scan)
    display(widgets.VBox([folder_input, run_button, scan_output, file_dropdown_output, preview_output]))

def watch_csv_results(df_index):
    """
    Displays a dropdown to select CSV file (from df_index),
    and a preview button. Stores the last selected file path
    as an attribute: watch_csv_results.selected_file_path
    """
    output = widgets.Output()
    if df_index is None or df_index.empty:
        print("⚠️ No CSV files scanned yet.")
        return

    # Internal state to store the selected file path
    state = {"selected_file_path": None}

    dropdown = widgets.Dropdown(
        options=[(row["File Name"], row["Full Path"]) for _, row in df_index.iterrows()],
        description='Select CSV:',
        layout=widgets.Layout(width='100%')
    )

    # Set initial state to dropdown's value
    state["selected_file_path"] = dropdown.value
    watch_csv_results.selected_file_path = dropdown.value  # set as function attribute too

    def on_select(change):
        if change['type'] == 'change' and change['name'] == 'value':
            state["selected_file_path"] = change['new']
            watch_csv_results.selected_file_path = change['new']  # keep updated for outside use

    dropdown.observe(on_select)

    preview_button = widgets.Button(description="🔄 Show Selected CSV Head")

    def show_preview(_):
        output.clear_output()
        file_path = state.get("selected_file_path", None)
        if not file_path:
            with output:
                print("⚠️ No CSV selected yet.")
            return
        try:
            df = pd.read_csv(file_path)
            with output:
                print(f"📊 Displaying: {os.path.basename(file_path)}")
                display(df.head())
        except Exception as e:
            with output:
                print(f"❌ Failed to load: {e}")

    preview_button.on_click(show_preview)

    display(widgets.VBox([dropdown, preview_button, output]))

def reload_all_modules(clear_cache=True):
    """
    Clears all Python modules in memory that are defined within your custom source folder.
    Optionally clears the curve analysis cache directory.
    """
    import sys, shutil, os

    python_files_root = _CUSTOM_PY_ROOT

    if clear_cache:
        cache_dir = "/content/curve_cache"
        if os.path.exists(cache_dir):
            shutil.rmtree(cache_dir)
            print(f"🧹 Cleared cache: {cache_dir}")
        else:
            print("ℹ️ Cache directory already clean.")

    to_delete = []
    for name, module in list(sys.modules.items()):
        try:
            module_file = getattr(module, '__file__', None)
            if module_file and os.path.commonpath([module_file, python_files_root]) == python_files_root:
                to_delete.append(name)
        except Exception:
            pass

    for name in to_delete:
        del sys.modules[name]

def force_fresh_import(module_name, file_path):
    if module_name in sys.modules:
        del sys.modules[module_name]

    loader = importlib.machinery.SourceFileLoader(module_name, file_path)
    spec = importlib.util.spec_from_loader(loader.name, loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    sys.modules[module_name] = module
    return module


def condense(func, *args, **kwargs):
    """
    Runs a function and captures all stdout/stderr output.
    After running, prints unique warnings/errors and counts repeated lines.
    Returns the original function's output.
    """
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = mystdout = io.StringIO()
    sys.stderr = mystderr = io.StringIO()
    try:
        result = func(*args, **kwargs)
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr

    output = mystdout.getvalue() + mystderr.getvalue()
    lines = [line.strip() for line in output.splitlines() if line.strip()]
    counter = Counter()
    other_lines = []
    for line in lines:
        if line.startswith("⚠️") or line.startswith("❌"):
            counter[line] += 1
        else:
            other_lines.append(line)

    for line, count in counter.items():
        if count > 1:
            print(f"{line} (repeated {count}x)")
        else:
            print(line)
    for line in other_lines:
        print(line)

    return result

def add_slider_widget(
    state_dict,
    key,
    description="",
    min_val=0,
    max_val=100,
    step=0.1,
    initial=None,
    callback=None
):
    """
    Returns a FloatRangeSlider or IntRangeSlider, updates state_dict[key] with (min, max) on change,
    and (if provided) calls callback() after value changes.
    """
    import ipywidgets as widgets

    # Set sensible default for initial if not provided
    if initial is None:
        initial = [min_val, max_val]
    # Use integer slider if all params are ints
    is_int_slider = (
        all(isinstance(x, int) or (isinstance(x, float) and x.is_integer())
            for x in [min_val, max_val, step] + list(initial))
        and float(step).is_integer()
    )
    if is_int_slider:
        slider = widgets.IntRangeSlider(
            value=[int(initial[0]), int(initial[1])],
            min=int(min_val),
            max=int(max_val),
            step=int(step),
            description=description,
            continuous_update=True,
            readout=True,
            layout=widgets.Layout(width='90%')
        )
        def handler(change):
            if change['type'] == 'change' and change['name'] == 'value':
                state_dict[key] = [int(v) for v in change['new']]
                if callback:
                    callback()
    else:
        slider = widgets.FloatRangeSlider(
            value=[float(initial[0]), float(initial[1])],
            min=float(min_val),
            max=float(max_val),
            step=float(step),
            description=description,
            continuous_update=True,
            readout=True,
            layout=widgets.Layout(width='90%')
        )
        def handler(change):
            if change['type'] == 'change' and change['name'] == 'value':
                state_dict[key] = [float(v) for v in change['new']]
                if callback:
                    callback()
    slider.observe(handler, names='value')
    return slider