# Utility — Function Reference

This package provides file discovery, CSV loading, interactive widgets, module
management, and output-formatting helpers used across all notebooks.

---

## csv_file_browser.py

The primary utility module. All plotting and processing modules import from here.

---

### `list_csv_files(target_folder)`

Recursively walks `target_folder` with `os.walk`, collecting all `.csv` files
(excluding macOS `._` metadata files). Sorts results alphabetically and returns
a DataFrame with columns:

| Column | Contents |
|---|---|
| `File Name` | Bare filename with extension |
| `Full Path` | Absolute path to the file |
| `Specimen ID` | Filename without extension |
| `Specimen Group` | Name of the immediate parent folder |

Also prints a count of found files.

---

### `build_df_index(folder)`

Same behaviour as `list_csv_files` but does **not** print output. Preferred for
programmatic use inside processing functions. Returns `None` if no CSVs are found.

**Returns** `pd.DataFrame` or `None`.

---

### `load_and_process_csv(file_path)`

Robust CSV loader. Steps performed:

1. Reads the file with `dtype=str` and `on_bad_lines='skip'` to tolerate
   malformed rows.
2. **Unit-row detection:** if the first data row contains more than half
   non-numeric, unit-like strings (e.g. `"MPa"`, `"%"`, `"[N]"`), those
   values are appended to the corresponding column headers and the row is
   dropped.
3. Converts all columns to numeric where possible (`errors='coerce'`).
4. Calls `Max_Processor.correct_stress_and_strain` to add zero-corrected
   stress/strain columns.
5. Sets `df.attrs['file_path']` for downstream labelling.

**Returns** a cleaned `pd.DataFrame` or `None` on error.

---

### `browse_csv_files_interactive(default_path)`

Full interactive CSV file browser for Jupyter/Colab.

Displays:
- A text field for the target folder path (default: `<repo_root>/input_data`)
- A "Scan for CSVs" button that calls `build_df_index` and populates a file dropdown
- A "Show Selected CSV Head" button that loads and previews the selected file

After interaction, stores three function-level attributes:
- `browse_csv_files_interactive.df_index`
- `browse_csv_files_interactive.selected_file_path`
- `browse_csv_files_interactive.selected_df`

These can be read by subsequent notebook cells.

---

### `watch_csv_results(df_index)`

Lightweight file selector. Displays a dropdown pre-populated from an existing
`df_index` and a preview button. Updates `watch_csv_results.selected_file_path`
whenever the dropdown selection changes.

Useful in notebooks where `build_df_index` has already been run and you just need
to pick a file without re-scanning.

---

### `reload_all_modules(clear_cache=True)`

Removes all modules from `sys.modules` whose `__file__` falls inside the
`custom_python_functions/` directory, forcing a fresh reimport on the next
`import` statement. Optionally deletes the Colab-local cache directory
`/content/curve_cache`.

Intended use: run this at the top of a notebook after editing a source file,
so changes take effect without restarting the kernel.

---

### `force_fresh_import(module_name, file_path)`

Loads a single module by absolute file path and forcibly replaces any existing
entry in `sys.modules`. Useful for one-off targeted reloads when only one module
has changed.

**Parameters**
- `module_name` — the dotted module name (e.g. `'Plotting.Single_Plot'`)
- `file_path` — absolute path to the `.py` file

**Returns** the freshly loaded module object.

---

### `condense(func, *args, **kwargs)`

Output-suppression wrapper. Captures all `stdout` and `stderr` produced by
`func(*args, **kwargs)`, then reprints the captured lines with deduplication:

- Lines starting with `⚠️` or `❌` are counted; if a line appears more than once
  it is printed once with a `(repeated Nx)` suffix.
- All other lines are printed as-is.

This keeps notebook output clean during batch processing where the same warning
may be emitted once per file (potentially hundreds of times).

**Returns** the original return value of `func`.

---

### `add_slider_widget(state_dict, key, description, min_val, max_val, step, initial, callback)`

Creates and returns a `FloatRangeSlider` or `IntRangeSlider` (chosen automatically
based on whether all parameters are integer-valued).

On each slider change:
1. Updates `state_dict[key]` with the new `[min, max]` tuple
2. Calls `callback()` if provided

Used by `plot_fivethirtyeight_style` to provide interactive axis-range controls
on stress-strain plots.

**Parameters**
- `state_dict` — mutable dict holding shared plot state
- `key` — the key in `state_dict` to update (e.g. `"x_range"`)
- `description` — slider label text
- `min_val`, `max_val` — slider bounds
- `step` — slider step size
- `initial` — `[lo, hi]` initial handle positions (defaults to `[min_val, max_val]`)
- `callback` — zero-argument callable to invoke after each value change

---

## Find_and_copy_data.py

---

### `find_and_copy_data(target_folder=None)`

Interactive utility for copying CSV files from a Google Drive folder to the local
Colab runtime at `/content/processed_csv_data/`.

Displays:
- A text field for the target folder path (default: `<repo_root>/input_data`)
- A "Scan Folder and Copy Files" button

On button click:
1. Validates the folder exists and lists its first 10 contents
2. Recursively finds all `.csv` files via `os.walk`
3. Copies each file to `/content/processed_csv_data/` preserving the relative
   subfolder structure (`shutil.copy2`)
4. Reports copy count and any errors

**Note:** this function is primarily a setup utility for fresh Colab sessions where
Drive latency makes working directly on Drive paths slow. After copying, subsequent
processing can run against the faster local copy.

---

## auto_init.py

---

### *(module-level script)*

Runs on import. Walks the `custom_python_functions/` directory tree and creates an
empty `__init__.py` in any subdirectory that does not already have one.

This ensures all subdirectories are recognised as Python packages regardless of
whether they were created by git, Colab Drive sync, or any other tool that may not
preserve empty files.
