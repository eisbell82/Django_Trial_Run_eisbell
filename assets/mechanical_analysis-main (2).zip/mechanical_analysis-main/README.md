# mechanical_analysis

Compression analysis pipeline for mycomaterial specimens.
Linked to: **Perez et al. 2025 — Mycotecture Phase II** (NASA NIAC Mycomaterials project).

Repository formatting and code bug fixes were assisted by Claude (Anthropic, claude-sonnet-4-6)

Notebooks extract sample strength and ductility from raw compression CSV data and produce
publication-quality SVG figures. All notebooks are designed to run in **Google Colab** and
read data from a mounted Google Drive.

---

## Repository Structure

```
mechanical_analysis/
├── input_data/                          # Raw compression CSVs, organized by specimen group
│   ├── OW1 Samples/
│   ├── OW2 Samples/
│   └── ...
├── custom_python_functions/             # Shared Python modules (imported by all notebooks)
│   ├── Plotting/
│   │   ├── Single_Plot.py              # Single-specimen stress-strain plotting + SVG export
│   │   ├── Multi_Plot.py               # Group curve plotting, bulk comparison, and SVG export
│   │   ├── Max_Processor.py            # Yield stress and inflection point extraction
│   │   ├── MOE_Processor.py            # Elastic modulus fitting, extraction, and SVG export
│   │   └── Polyfit_Processor.py        # Polynomial fitting utilities
│   └── Utility/
│       ├── csv_file_browser.py         # CSV loading, indexing, and interactive file browser
│       └── Find_and_copy_data.py       # Data discovery utilities
├── compression_single_strength_plot/   # Notebook: single-specimen strength and ductility
├── compression_single_MoE_plot/        # Notebook: single-specimen elastic modulus
├── compression_multi_strength_plot/    # Notebook: multi-specimen group stress-strain and MOE
└── compression_bulk_data_plot/         # Notebook: bulk group summary with interactive plots
```

---

## Notebooks

### Single-Specimen Strength Analysis
`compression_single_strength_plot/compression_single_strength_plot.ipynb`

Interactive tool for reviewing individual compression test CSVs. Fits a polynomial to the
stress-strain curve for mechanical analysis, identifies yield stress and inflection points,
and plots results interactively. Batch-exports one SVG per specimen.

**Output:** `compression_single_strength_plot/output data/<specimen_name>_strength.svg`

---

### Single-Specimen Modulus of Elasticity
`compression_single_MoE_plot/compression_single_MoE_plot.ipynb`

Interactive tool for reviewing elastic modulus fits on individual CSVs. Fits the linear
elastic region of the stress-strain curve and displays MOE and R² per specimen.
Batch-exports one MOE SVG per specimen.

**Output:** `compression_single_MoE_plot/output data/<specimen_name>_moe.svg`

---

### Multi-Specimen Group Analysis
`compression_multi_strength_plot/compression_multi_strength_plot.ipynb`

Batch-processes all CSVs organized by subfolder (specimen group). Provides interactive
per-group stress-strain curve plots with strength and ductility markers, overlaid MOE fit
lines, and group-level summary statistics. Batch-exports one strength SVG and one MOE SVG
per group.

**Output:** `compression_multi_strength_plot/output data/<group_name>_strength.svg`
**Output:** `compression_multi_strength_plot/output data/<group_name>_moe.svg`

---

### Bulk Data Summary
`compression_bulk_data_plot/compression_bulk_data_plot.ipynb`

Processes all CSVs in `input_data/`, extracts yield stress, inflection points, and elastic
modulus per specimen, and generates interactive group-level comparison plots (mean ± std,
dual-axis strength + ductility). Includes a widget-based SVG export that captures the
current plot configuration.

**Output:** `compression_bulk_data_plot/output data/`

---

## Usage

1. Download repository and extract in a location in your drive
2. Upload/replace data in `input_data/` with your personal csv data in any folder structure you desire (note that the folders will define sample groups, folder levels are agnostic to groups)
3. Open any of the notebooks in **Google Colab**
4. Run **Cell 1** (`Mount Google Drive, clean cache, and load Python packages`)
5. Update `repo_root` to the location of this repository in your Google Drive:
   ```python
   repo_root = "/content/drive/MyDrive/mechanical_analysis"
   ```
6. Run cells top to bottom. Interactive cells display widget controls inline.
7. Export cells save SVG figures to the notebook's `output data/` folder. The `output_folder`
   path can be adjusted via the `@param` field in Colab.

---

## Data Format

Source data is read from `input_data/`. Output SVGs are written to `output data/` inside
each notebook's folder. Sidecar JSON files (`.curve_analysis.json`, `.modulus.json`) are
written automatically alongside each CSV on first processing and reused as a cache on
subsequent runs to avoid redundant computation.

SVG files are named `<specimen_or_group>_strength.svg` or `<specimen_or_group>_moe.svg`
to distinguish strength and elastic modulus plots when both are exported to the same folder.

---

## Dependencies

All dependencies are available in the standard Google Colab environment:

- `numpy`, `pandas`, `matplotlib`
- `ipywidgets`, `IPython`
- `google.colab` (drive mount, file browser)
